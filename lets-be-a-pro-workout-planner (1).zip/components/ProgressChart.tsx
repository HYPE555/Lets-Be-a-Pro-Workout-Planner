import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ExerciseLog } from '../types';

interface ProgressChartProps {
  exerciseName: string;
  data: ExerciseLog[];
}

const KG_TO_LBS = 2.20462;

export const ProgressChart: React.FC<ProgressChartProps> = ({ exerciseName, data }) => {
  const [metric, setMetric] = useState<'weight' | 'reps' | 'volume'>('weight');
  const [unit, setUnit] = useState<'kg' | 'lbs'>('kg');
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });

  const handleResetFilters = () => {
    setDateRange({ start: '', end: '' });
  };

  const processedData = useMemo(() => {
    const startDate = dateRange.start ? new Date(dateRange.start) : null;
    // To make the end date inclusive, set the time to the end of the day
    const endDate = dateRange.end ? new Date(dateRange.end) : null;
    if (endDate) {
        endDate.setHours(23, 59, 59, 999);
    }


    return data
      .filter(log => {
        const logDate = new Date(log.date);
        const isAfterStart = !startDate || logDate >= startDate;
        const isBeforeEnd = !endDate || logDate <= endDate;
        return isAfterStart && isBeforeEnd;
      })
      .map(log => {
        const displayWeight = unit === 'lbs' ? log.weight * KG_TO_LBS : log.weight;
        let displayValue;
        switch (metric) {
          case 'reps':
            displayValue = log.reps;
            break;
          case 'volume':
            displayValue = displayWeight * log.reps;
            break;
          case 'weight':
          default:
            displayValue = displayWeight;
            break;
        }

        return {
          ...log,
          dateFormatted: new Date(log.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
          displayValue: displayValue,
          displayWeight: displayWeight,
        };
      });
  }, [data, metric, unit, dateRange]);

  const yAxisLabel = `${metric.charAt(0).toUpperCase() + metric.slice(1)}${metric !== 'reps' ? ` (${unit})` : ''}`;
  const legendName = `${metric.charAt(0).toUpperCase() + metric.slice(1)}`;

  const ControlButton: React.FC<{ isActive: boolean; onClick: () => void; children: React.ReactNode }> = ({ isActive, onClick, children }) => (
    <button
      onClick={onClick}
      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${isActive ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}
    >
      {children}
    </button>
  );

  return (
    <div className="bg-gray-800/50 rounded-2xl p-4 backdrop-blur-sm border border-gray-700 flex flex-col">
      <h3 className="text-lg font-bold text-white mb-4">{exerciseName}</h3>
      
      <div className="flex flex-col sm:flex-row flex-wrap gap-x-6 gap-y-3 items-center mb-4 text-sm">
        <div className="flex items-center gap-2">
            <span className="font-medium text-gray-400">Metric:</span>
            <ControlButton isActive={metric === 'weight'} onClick={() => setMetric('weight')}>Weight</ControlButton>
            <ControlButton isActive={metric === 'reps'} onClick={() => setMetric('reps')}>Reps</ControlButton>
            <ControlButton isActive={metric === 'volume'} onClick={() => setMetric('volume')}>Volume</ControlButton>
        </div>
        <div className="flex items-center gap-2">
            <span className="font-medium text-gray-400">Unit:</span>
            <ControlButton isActive={unit === 'kg'} onClick={() => setUnit('kg')}>kg</ControlButton>
            <ControlButton isActive={unit === 'lbs'} onClick={() => setUnit('lbs')}>lbs</ControlButton>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row flex-wrap gap-x-4 gap-y-3 items-center mb-4 text-sm">
        <div className="flex items-center gap-2">
          <label htmlFor={`startDate-${exerciseName}`} className="font-medium text-gray-400">From:</label>
          <input 
            type="date" 
            id={`startDate-${exerciseName}`}
            value={dateRange.start} 
            onChange={e => setDateRange(prev => ({ ...prev, start: e.target.value }))}
            className="bg-gray-700 border border-gray-600 rounded-md py-1 px-2 text-white text-xs w-32"
          />
        </div>
        <div className="flex items-center gap-2">
           <label htmlFor={`endDate-${exerciseName}`} className="font-medium text-gray-400">To:</label>
           <input 
            type="date" 
            id={`endDate-${exerciseName}`}
            value={dateRange.end} 
            onChange={e => setDateRange(prev => ({ ...prev, end: e.target.value }))}
            className="bg-gray-700 border border-gray-600 rounded-md py-1 px-2 text-white text-xs w-32"
           />
        </div>
        <button onClick={handleResetFilters} className="text-cyan-400 hover:text-cyan-300 text-xs font-semibold">Reset Dates</button>
      </div>

      <div style={{ width: '100%', height: 300, flexGrow: 1 }}>
        {processedData.length > 0 ? (
            <ResponsiveContainer>
            <LineChart
                data={processedData}
                margin={{ top: 5, right: 20, left: -5, bottom: 5 }}
            >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                <XAxis dataKey="dateFormatted" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis 
                    stroke="#9ca3af" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    domain={['dataMin - 1', 'auto']}
                    label={{ value: yAxisLabel, angle: -90, position: 'insideLeft', fill: '#9ca3af', dx: -10 }} 
                />
                <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '0.5rem' }}
                labelStyle={{ color: '#f3f4f6', fontWeight: 'bold' }}
                formatter={(value: number, name, props) => {
                    if (props.payload && props.payload.length > 0) {
                        const dataPoint = props.payload[0].payload;
                        const weightText = `${dataPoint.displayWeight.toFixed(1)} ${unit}`;
                        const repText = `${dataPoint.reps} reps`;
                        const fullText = `${weightText} for ${repText}`;
                        return [fullText, `Performance`];
                    }
                    return [value, name];
                }}
                />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '14px' }}/>
                <Line type="monotone" dataKey="displayValue" name={legendName} stroke="#38bdf8" strokeWidth={2} dot={{ r: 4, fill: '#38bdf8' }} activeDot={{ r: 6, strokeWidth: 2 }} />
            </LineChart>
            </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
                <p>No data available for this selection.</p>
            </div>
        )}
      </div>
    </div>
  );
};