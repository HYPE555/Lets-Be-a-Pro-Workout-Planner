import React, { useState } from 'react';
import { WorkoutPlan, Day, ExerciseLog } from '../types';
import { DumbbellIcon } from './icons/DumbbellIcon';
import { RunIcon } from './icons/RunIcon';
import { YogaIcon } from './icons/YogaIcon';
import { InfoIcon } from './icons/InfoIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface TimetableDisplayProps {
  plan: WorkoutPlan;
  onLogExercise?: (log: Omit<ExerciseLog, 'date'>) => void;
}

const getDayIcon = (focus: string) => {
    const lowerFocus = focus.toLowerCase();
    if (lowerFocus.includes('rest') || lowerFocus.includes('recovery')) {
        return <YogaIcon className="w-6 h-6 text-green-400" />;
    }
    if (lowerFocus.includes('cardio') || lowerFocus.includes('endurance') || lowerFocus.includes('hiit')) {
        return <RunIcon className="w-6 h-6 text-rose-400" />;
    }
    return <DumbbellIcon className="w-6 h-6 text-amber-400" />;
}

export const TimetableDisplay: React.FC<TimetableDisplayProps> = ({ plan, onLogExercise }) => {
  const [activeDay, setActiveDay] = useState<Day>(plan.weeklyPlan.find(d => d.focus !== 'Rest Day')?.day || 'Monday');
  const [expandedExercise, setExpandedExercise] = useState<number | null>(null);
  const [loggingIndex, setLoggingIndex] = useState<number | null>(null);
  const [logWeight, setLogWeight] = useState('');
  const [logReps, setLogReps] = useState('');

  const activeWorkout = plan.weeklyPlan.find(d => d.day === activeDay);

  const toggleExerciseDetails = (index: number) => {
    setExpandedExercise(prevIndex => (prevIndex === index ? null : index));
    if (loggingIndex !== null) setLoggingIndex(null);
  };

  const handleToggleLogForm = (index: number) => {
    if (loggingIndex === index) {
      setLoggingIndex(null);
    } else {
      setLoggingIndex(index);
      setLogWeight('');
      setLogReps('');
      if (expandedExercise !== null) setExpandedExercise(null);
    }
  };
  
  const handleSaveLog = (exerciseName: string) => {
    if (onLogExercise && logWeight && logReps) {
      onLogExercise({
        exerciseName,
        weight: parseFloat(logWeight),
        reps: parseInt(logReps, 10),
      });
      setLoggingIndex(null);
      setLogWeight('');
      setLogReps('');
    }
  };
  
  const handleDownload = () => {
    let content = "Your AI-Generated Weekly Workout Plan\n";
    content += "========================================\n\n";

    plan.weeklyPlan.forEach(day => {
        content += `--- ${day.day.toUpperCase()} ---\n`;
        content += `Focus: ${day.focus}\n\n`;

        if (day.focus === 'Rest Day') {
            content += `Today is a rest day. ${day.cooldown || 'Enjoy your recovery!'}\n\n`;
        } else {
            content += `Warm-up:\n${day.warmup}\n\n`;
            content += `Exercises:\n`;
            day.exercises.forEach(ex => {
                content += `- ${ex.name}: ${ex.sets} sets of ${ex.reps} reps, with ${ex.rest} rest.\n`;
            });
            content += `\n`;
            content += `Cool-down:\n${day.cooldown}\n\n`;
        }
        content += "========================================\n\n";
    });

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ai-workout-plan.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">Your Weekly Plan</h2>
        <button 
            onClick={handleDownload}
            className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200"
            aria-label="Download workout plan"
        >
            <DownloadIcon className="w-5 h-5" />
            <span>Download</span>
        </button>
      </div>
      
      <div className="flex justify-center mb-6 overflow-x-auto pb-2 -mx-4 px-4">
        <div className="flex space-x-2 bg-gray-900 p-1.5 rounded-xl">
            {plan.weeklyPlan.map(dayPlan => (
            <button
                key={dayPlan.day}
                onClick={() => {
                  setActiveDay(dayPlan.day);
                  setExpandedExercise(null);
                  setLoggingIndex(null);
                }}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 ${
                activeDay === dayPlan.day ? 'bg-cyan-500 text-white shadow-md' : 'text-gray-300 hover:bg-gray-700'
                }`}
            >
                {dayPlan.day.substring(0,3)}
            </button>
            ))}
        </div>
      </div>

      {activeWorkout && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 transition-all duration-300">
          <div className="flex items-center gap-4 mb-4">
            {getDayIcon(activeWorkout.focus)}
            <div>
                <h3 className="text-2xl font-bold text-white">{activeWorkout.day}</h3>
                <p className="text-cyan-400 font-medium">{activeWorkout.focus}</p>
            </div>
          </div>
          
          {activeWorkout.focus === 'Rest Day' ? (
            <p className="text-gray-400 mt-4">{activeWorkout.cooldown || "Take a day to rest and recover. Light stretching or a short walk is recommended."}</p>
          ) : (
            <div className="space-y-6">
                <div>
                    <h4 className="font-semibold text-lg mb-2 text-gray-200">Warm-up</h4>
                    <p className="text-gray-400">{activeWorkout.warmup}</p>
                </div>
              
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="text-gray-400 text-sm">
                            <tr>
                                <th className="pb-2 font-medium">Exercise</th>
                                <th className="pb-2 font-medium text-center">Sets</th>
                                <th className="pb-2 font-medium text-center">Reps</th>
                                <th className="pb-2 font-medium text-right">Rest</th>
                                {onLogExercise && <th className="pb-2 font-medium text-center">Log</th>}
                                <th className="pb-2 font-medium text-right pr-2">Info</th>
                            </tr>
                        </thead>
                        <tbody>
                        {activeWorkout.exercises.map((ex, index) => (
                            <React.Fragment key={index}>
                              <tr className="border-b border-gray-700">
                                  <td className="py-3 pr-4 font-medium text-white">{ex.name}</td>
                                  <td className="py-3 px-2 text-center text-gray-300">{ex.sets}</td>
                                  <td className="py-3 px-2 text-center text-gray-300">{ex.reps}</td>
                                  <td className="py-3 pl-4 text-right text-gray-300">{ex.rest}</td>
                                  {onLogExercise && (
                                    <td className="py-3 text-center">
                                      <button onClick={() => handleToggleLogForm(index)} aria-expanded={loggingIndex === index} aria-controls={`exercise-log-${index}`} className="text-cyan-400 hover:text-cyan-300 transition-colors">
                                        <PlusCircleIcon className="w-5 h-5 mx-auto" />
                                      </button>
                                    </td>
                                  )}
                                  <td className="py-3 pl-2 text-right">
                                    <button onClick={() => toggleExerciseDetails(index)} aria-expanded={expandedExercise === index} aria-controls={`exercise-desc-${index}`} className="text-cyan-400 hover:text-cyan-300 transition-colors">
                                      <InfoIcon className="w-5 h-5" />
                                    </button>
                                  </td>
                              </tr>
                              {expandedExercise === index && (
                                <tr id={`exercise-desc-${index}`}>
                                  <td colSpan={onLogExercise ? 6 : 5} className="py-3 px-4 text-sm text-gray-400 bg-gray-900/50">
                                    <div>
                                        <p className="font-semibold text-gray-200 mb-1">Form Tip:</p>
                                        <p>{ex.description}</p>
                                    </div>
                                    {ex.variations && ex.variations.length > 0 && (
                                        <div className="mt-4 pt-3 border-t border-gray-700">
                                            <h5 className="font-semibold text-gray-200 mb-2 flex items-center gap-2">
                                                <LightbulbIcon className="w-4 h-4 text-yellow-400" />
                                                Variations
                                            </h5>
                                            <ul className="list-disc list-inside space-y-2 pl-1">
                                                {ex.variations.map((variation, vIndex) => (
                                                    <li key={vIndex}>
                                                        <span className="font-medium text-gray-300">{variation.name}:</span> {variation.description}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                  </td>
                                </tr>
                              )}
                               {loggingIndex === index && (
                                <tr id={`exercise-log-${index}`}>
                                  <td colSpan={onLogExercise ? 6 : 5} className="py-3 px-4 bg-gray-900/50">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <p className="font-semibold text-gray-200 text-sm mr-2">Log Performance:</p>
                                      <input type="number" placeholder="Weight (kg)" value={logWeight} onChange={(e) => setLogWeight(e.target.value)} className="w-24 bg-gray-700 border border-gray-600 rounded-md py-1 px-2 text-white text-sm" />
                                      <input type="number" placeholder="Reps" value={logReps} onChange={(e) => setLogReps(e.target.value)} className="w-20 bg-gray-700 border border-gray-600 rounded-md py-1 px-2 text-white text-sm" />
                                      <button onClick={() => handleSaveLog(ex.name)} className="bg-cyan-500 text-white text-sm font-semibold px-3 py-1.5 rounded-md hover:bg-cyan-600 transition-colors disabled:opacity-50" disabled={!logWeight || !logReps}>Save</button>
                                      <button onClick={() => setLoggingIndex(null)} className="text-gray-400 text-sm hover:text-white ml-auto sm:ml-2">Cancel</button>
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                        ))}
                        </tbody>
                    </table>
                </div>

                <div>
                    <h4 className="font-semibold text-lg mb-2 text-gray-200">Cool-down</h4>
                    <p className="text-gray-400">{activeWorkout.cooldown}</p>
                </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};