import React, { useState, useMemo, useEffect } from 'react';
import { WorkoutLog, ExerciseLog } from '../types';
import { TimetableDisplay } from './TimetableDisplay';
import { ChartBarIcon } from './icons/ChartBarIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { ProgressChart } from './ProgressChart';
import { searchExercises } from '../services/geminiService';
import { SearchIcon } from './icons/SearchIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';

interface StatsViewProps {
  history: WorkoutLog[];
  progressData: ExerciseLog[];
  onLogExercise?: (log: Omit<ExerciseLog, 'date'>) => void;
  isCoachView?: boolean;
}

const ManualLogForm: React.FC<{ onLogExercise: (log: Omit<ExerciseLog, 'date'>) => void; }> = ({ onLogExercise }) => {
    const [exerciseName, setExerciseName] = useState('');
    const [weight, setWeight] = useState('');
    const [reps, setReps] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<{ name: string; description: string }[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [isInputFocused, setIsInputFocused] = useState(false);


    useEffect(() => {
        if (searchQuery.length < 3) {
          setSearchResults([]);
          if (isSearching) setIsSearching(false);
          return;
        }
    
        const handler = setTimeout(async () => {
          setIsSearching(true);
          try {
            const results = await searchExercises(searchQuery);
            setSearchResults(results);
          } catch (error) {
            console.error("Exercise search failed:", error);
            setSearchResults([]);
          } finally {
            setIsSearching(false);
          }
        }, 500); // 500ms debounce
    
        return () => {
          clearTimeout(handler);
        };
      }, [searchQuery]);

    const handleSelectExercise = (name: string) => {
        setExerciseName(name);
        setSearchQuery(name);
        setSearchResults([]);
        setIsInputFocused(false);
    };

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setExerciseName(e.target.value);
        setSearchQuery(e.target.value);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (exerciseName.trim() && weight && reps) {
            onLogExercise({
                exerciseName: exerciseName.trim(),
                weight: parseFloat(weight),
                reps: parseInt(reps, 10),
            });
            // Reset form
            setExerciseName('');
            setSearchQuery('');
            setWeight('');
            setReps('');
        }
    };
    
    const canSubmit = exerciseName.trim() && weight && reps;

    return (
        <section className="bg-gray-800 rounded-2xl border border-gray-700 p-6">
            <h2 className="text-2xl font-bold text-white mb-4">Log an Exercise</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="md:col-span-2 relative">
                    <label htmlFor="exerciseName" className="block text-sm font-medium text-gray-300 mb-2">Exercise Name</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <SearchIcon className="w-5 h-5 text-gray-400" />
                        </div>
                        <input
                            type="text"
                            id="exerciseName"
                            value={exerciseName}
                            onChange={handleNameChange}
                            onFocus={() => setIsInputFocused(true)}
                            onBlur={() => setTimeout(() => setIsInputFocused(false), 150)} // Delay to allow click
                            placeholder="e.g., 'Bench Press'"
                            className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 pl-10 pr-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                            autoComplete="off"
                        />
                    </div>
                    {isInputFocused && (isSearching || searchResults.length > 0) && (
                        <div className="absolute mt-1 w-full z-10 bg-gray-900 border border-gray-700 rounded-lg max-h-60 overflow-y-auto shadow-lg">
                            {isSearching ? <p className="text-sm text-gray-400 p-3 animate-pulse">Searching...</p> : (
                                <ul className="divide-y divide-gray-700">
                                    {searchResults.map((ex, index) => (
                                        <li key={index} onMouseDown={() => handleSelectExercise(ex.name)} className="px-4 py-3 cursor-pointer hover:bg-gray-800 transition-colors">
                                            <p className="font-semibold text-white text-sm">{ex.name}</p>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    )}
                </div>
                <div>
                    <label htmlFor="weight" className="block text-sm font-medium text-gray-300 mb-2">Weight (kg)</label>
                    <input type="number" id="weight" value={weight} onChange={e => setWeight(e.target.value)} placeholder="e.g., 60" className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500" />
                </div>
                <div>
                    <label htmlFor="reps" className="block text-sm font-medium text-gray-300 mb-2">Reps</label>
                    <input type="number" id="reps" value={reps} onChange={e => setReps(e.target.value)} placeholder="e.g., 8" className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500" />
                </div>
                 <button type="submit" disabled={!canSubmit} className="w-full flex items-center justify-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2.5 px-4 rounded-lg shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
                    <PlusCircleIcon className="w-5 h-5" />
                    Log
                </button>
            </form>
        </section>
    );
};

export const StatsView: React.FC<StatsViewProps> = ({ history, progressData, onLogExercise, isCoachView = false }) => {
    const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

    const progressByExercise = useMemo(() => {
        return progressData.reduce((acc, log) => {
            if (!acc[log.exerciseName]) {
                acc[log.exerciseName] = [];
            }
            acc[log.exerciseName].push(log);
            return acc;
        }, {} as Record<string, ExerciseLog[]>);
    }, [progressData]);

    const chartableExercises = Object.entries(progressByExercise).filter(([name, logs]) => (logs as ExerciseLog[]).length > 1);

    const toggleLogDetails = (id: string) => {
        setExpandedLogId(prevId => (prevId === id ? null : id));
    };

  const noHistoryMessage = isCoachView 
    ? "This player hasn't generated any plans or logged any exercises yet."
    : "You haven't generated any plans or logged any exercises yet.";
    
  const noHistorySubMessage = isCoachView 
    ? ""
    : "Use the form above to log your first exercise, or generate a plan to get started!";

  if (history.length === 0 && progressData.length === 0) {
    return (
        <div className="max-w-4xl mx-auto space-y-12 animate-fade-in">
            {onLogExercise && <ManualLogForm onLogExercise={onLogExercise} />}
            <div className="text-center text-gray-500 bg-gray-800/50 rounded-2xl shadow-lg p-8 backdrop-blur-sm border border-gray-700">
                <ChartBarIcon className="w-12 h-12 mx-auto text-gray-600 mb-4" />
                <h2 className="text-2xl font-bold text-white mb-2">No History Found</h2>
                <p>{noHistoryMessage}</p>
                <p>{noHistorySubMessage}</p>
            </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-fade-in">
        {onLogExercise && <ManualLogForm onLogExercise={onLogExercise} />}

        {chartableExercises.length > 0 && (
            <section>
                <h2 className="text-3xl font-bold text-white text-center mb-6">Progress Overview</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {chartableExercises.map(([exerciseName, logs]) => (
                        <ProgressChart key={exerciseName} exerciseName={exerciseName} data={logs as ExerciseLog[]} />
                    ))}
                </div>
            </section>
        )}

        {history.length > 0 && (
            <section>
                <h2 className="text-3xl font-bold text-white text-center mb-6">Workout History</h2>
                <div className="space-y-4">
                {history.map(log => (
                    <div key={log.id} className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden">
                        <button
                            onClick={() => toggleLogDetails(log.id)}
                            className="w-full text-left p-4 hover:bg-gray-700/50 transition-colors"
                            aria-expanded={expandedLogId === log.id}
                            aria-controls={`log-details-${log.id}`}
                        >
                            <div className="flex justify-between items-center">
                                <div>
                                    <div className="flex items-center gap-3">
                                        <CalendarIcon className="w-5 h-5 text-cyan-400" />
                                        <p className="font-bold text-lg text-white">Workout Plan - {log.date}</p>
                                    </div>
                                    <p className="text-sm text-gray-400 ml-8">Goals: {log.preferences.goals.join(', ')}</p>
                                </div>
                                <svg className={`w-6 h-6 text-gray-400 transition-transform ${expandedLogId === log.id ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </button>
                        {expandedLogId === log.id && (
                            <div id={`log-details-${log.id}`} className="p-4 bg-gray-900/50 border-t border-gray-700">
                                <TimetableDisplay plan={log.plan} onLogExercise={onLogExercise} />
                            </div>
                        )}
                    </div>
                ))}
                </div>
            </section>
        )}
    </div>
  );
};