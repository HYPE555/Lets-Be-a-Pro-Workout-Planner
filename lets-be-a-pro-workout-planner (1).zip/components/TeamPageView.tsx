import React, { useState, useEffect, useRef } from 'react';
import { Team, UserProfile, Invitation, UserSpecificData, ExerciseLog, PlayerStatSummary, TeamMessage, ActivityLog } from '../types';
import { UsersIcon } from './icons/UsersIcon';
import { UserIcon } from './icons/UserIcon';
import { ChartBarIcon } from './icons/ChartBarIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { TrophyIcon } from './icons/TrophyIcon';
import { FlagIcon } from './icons/FlagIcon';
import { SendIcon } from './icons/SendIcon';
import { DumbbellIcon } from './icons/DumbbellIcon';

interface TeamPageViewProps {
  team: Team;
  profile: UserProfile;
  users: UserProfile[];
  invitations: Invitation[];
  setProfile: (profileUpdater: (prev: UserProfile) => UserProfile) => void;
  onSendInvite: (teamId: string, email: string) => void;
  setToast: (toast: { message: string; type: 'success' | 'error' } | null) => void;
  onCreateChallenge: (teamId: string, title: string, description: string, startDate?: string, endDate?: string) => void;
  onViewPlayerStats: (player: UserProfile) => void;
  onViewPublicProfile: (user: UserProfile) => void;
  messages: TeamMessage[];
  onSendMessage: (teamId: string, message: string) => void;
  onBack: () => void;
  activityFeed: ActivityLog[];
}

const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.round((now.getTime() - date.getTime()) / 1000);
    const minutes = Math.round(seconds / 60);
    const hours = Math.round(minutes / 60);
    const days = Math.round(hours / 24);

    if (seconds < 10) return `just now`;
    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
};


export const TeamPageView: React.FC<TeamPageViewProps> = ({
  team,
  profile,
  users,
  invitations,
  setProfile,
  onSendInvite,
  setToast,
  onCreateChallenge,
  onViewPlayerStats,
  onViewPublicProfile,
  messages,
  onSendMessage,
  onBack,
  activityFeed,
}) => {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteError, setInviteError] = useState<string | null>('');
  const [playerStats, setPlayerStats] = useState<Record<string, PlayerStatSummary>>({});
  const [challengeTitle, setChallengeTitle] = useState('');
  const [challengeDesc, setChallengeDesc] = useState('');
  const [challengeStartDate, setChallengeStartDate] = useState('');
  const [challengeEndDate, setChallengeEndDate] = useState('');
  const [showChallengeForm, setShowChallengeForm] = useState(false);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [activityFilter, setActivityFilter] = useState<'all' | 'workout_plan' | 'exercise_log'>('all');

  const members = users.filter(u => u.teamId === team.id);
  const players = members.filter(u => u.role === 'player');
  const teamMessages = messages.filter(m => m.teamId === team.id).sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const teamMemberIds = new Set(members.map(m => m.userId));
  const teamActivityFeed = activityFeed
      .filter(act => teamMemberIds.has(act.userId))
      .filter(act => activityFilter === 'all' || act.type === activityFilter);


  useEffect(() => {
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [teamMessages]);

  useEffect(() => {
    if (profile.role === 'coach') {
        const stats: Record<string, PlayerStatSummary> = {};
        for (const member of players) {
            try {
                const savedData = localStorage.getItem(`userData_${member.userId}`);
                if (savedData) {
                    const userData: UserSpecificData = JSON.parse(savedData);
                    const history = userData.history || [];
                    const progressData = userData.progressData || [];

                    const pbs: Record<string, { weight: number; reps: number }> = {};
                    const progressByExercise = progressData.reduce((acc, log) => {
                        if (!acc[log.exerciseName]) acc[log.exerciseName] = [];
                        acc[log.exerciseName].push(log);
                        return acc;
                    }, {} as Record<string, ExerciseLog[]>);

                    for (const exerciseName in progressByExercise) {
                        const logs = progressByExercise[exerciseName];
                        const bestLog = logs.reduce((best, current) => current.weight > best.weight ? current : best, logs[0]);
                        pbs[exerciseName] = { weight: bestLog.weight, reps: bestLog.reps };
                    }
                    const sortedPbs = Object.entries(pbs).sort(([, a], [, b]) => b.weight - a.weight).slice(0, 3);
                    
                    stats[member.userId] = {
                        totalWorkouts: history.length,
                        personalBests: Object.fromEntries(sortedPbs),
                    };
                } else {
                     stats[member.userId] = { totalWorkouts: 0, personalBests: {} };
                }
            } catch (e) {
                console.error(`Failed to load stats for ${member.name}`, e);
                stats[member.userId] = { totalWorkouts: 0, personalBests: {} };
            }
        }
        setPlayerStats(stats);
    }
  }, [team.id, players, profile.role, users]);
  
  const validateEmail = (email: string): string | null => {
    if (!email) return "Email cannot be empty.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email format.";
    return null;
  };

  const handleInviteEmailChange = (email: string) => {
    setInviteEmail(email);
    setInviteError(validateEmail(email));
  };

  const handleSendInvite = () => {
    const error = validateEmail(inviteEmail);
    if (error) {
        setInviteError(error);
        return;
    }
    onSendInvite(team.id, inviteEmail);
    setInviteEmail('');
    setInviteError(null);
  };
  
  const handleSendChallenge = () => {
    if (challengeTitle.trim() && challengeDesc.trim()) {
        onCreateChallenge(team.id, challengeTitle, challengeDesc, challengeStartDate || undefined, challengeEndDate || undefined);
        setChallengeTitle('');
        setChallengeDesc('');
        setChallengeStartDate('');
        setChallengeEndDate('');
        setShowChallengeForm(false);
    }
  };

  const handleSendMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
        onSendMessage(team.id, newMessage);
        setNewMessage('');
    }
  };
  
  const handleCoachTeam = () => {
    if (profile.teamId) {
        setToast({ message: "You can only coach one team at a time. Please leave your current team first.", type: 'error' });
    } else {
        setProfile(prev => ({ ...prev, teamId: team.id }));
        setToast({ message: `You are now coaching ${team.name}.`, type: 'success' });
    }
  };

  const handleJoinTeam = () => {
    if (profile.role === 'player' && !profile.teamId) {
      setProfile(prev => ({ ...prev, teamId: team.id }));
      setToast({ message: `You have successfully joined ${team.name}!`, type: 'success' });
    }
  };
  
  const isCurrentUserMember = profile.teamId === team.id;
  const isCoachOrPlayerMember = isCurrentUserMember && (profile.role === 'player' || profile.role === 'coach');

  const confirmLeaveTeam = () => {
    if ((profile.role === 'player' || profile.role === 'coach') && isCurrentUserMember) {
      const teamName = team.name;
      setProfile(prev => {
        const { teamId, ...rest } = prev;
        return rest;
      });
      setToast({ message: `You have successfully left ${teamName}.`, type: 'success' });
      setShowLeaveConfirm(false);
      onBack();
    } else {
      setShowLeaveConfirm(false);
    }
  };

  const isCoachLeaving = profile.role === 'coach';
  const leaveModalTitle = isCoachLeaving ? 'Confirm Stop Coaching' : 'Confirm Leave Team';
  const leaveModalText = isCoachLeaving
      ? `Are you sure you want to stop coaching "${team.name}"?`
      : `Are you sure you want to leave "${team.name}"?`;
  const leaveModalButtonText = isCoachLeaving ? 'Stop Coaching' : 'Leave';

  const FilterButton: React.FC<{ filter: typeof activityFilter, label: string }> = ({ filter, label }) => (
    <button
        onClick={() => setActivityFilter(filter)}
        className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${activityFilter === filter ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}
    >
        {label}
    </button>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
       {showLeaveConfirm && (
         <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 shadow-xl">
            <h3 className="text-lg font-bold text-white">{leaveModalTitle}</h3>
            <p className="text-gray-400 mt-2">{leaveModalText}</p>
            <div className="flex justify-end gap-4 mt-6">
              <button onClick={() => setShowLeaveConfirm(false)} className="px-4 py-2 rounded-lg text-gray-300 bg-gray-600 hover:bg-gray-500">Cancel</button>
              <button onClick={confirmLeaveTeam} className="px-4 py-2 rounded-lg text-white bg-red-500 hover:bg-red-600 font-semibold">{leaveModalButtonText}</button>
            </div>
          </div>
        </div>
      )}

        <header className="flex justify-between items-center">
            <button
                onClick={onBack}
                className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
            >
                &larr; Back to All Teams
            </button>
            {profile.role === 'coach' && !isCurrentUserMember && (
                <button
                    onClick={handleCoachTeam}
                    className="bg-cyan-600 hover:bg-cyan-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                >
                    Coach This Team
                </button>
            )}
            {isCurrentUserMember && (profile.role === 'player' || profile.role === 'coach') && (
                <button
                    onClick={() => setShowLeaveConfirm(true)}
                    className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                >
                    {profile.role === 'coach' ? 'Stop Coaching' : 'Leave Team'}
                </button>
            )}
        </header>

      <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center gap-3 mb-1">
            <h1 className="text-3xl font-bold text-white">{team.name}</h1>
            <span className="text-sm font-medium text-gray-300 bg-gray-700/50 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                <UsersIcon className="w-4 h-4 text-cyan-400" />
                {players.length} Players
            </span>
        </div>
        <p className="font-mono text-md text-cyan-300 tracking-wider">Join Code: {team.joinCode}</p>
        {profile.role === 'player' && !profile.teamId && (
            <div className="mt-4">
                <button
                    onClick={handleJoinTeam}
                    className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg transition-colors text-lg"
                >
                    Join Team
                </button>
            </div>
        )}
      </section>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
            <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
                <h2 className="text-xl font-bold text-white mb-4">Team Roster</h2>
                {players.length > 0 ? (
                    <ul className="space-y-2">
                        {players.map(member => (
                            <li key={member.userId} className="p-2 rounded-md hover:bg-gray-800/50 transition-colors">
                                <div className="flex items-center justify-between gap-3">
                                    <div className="flex items-center gap-3">
                                        <UserIcon className="w-5 h-5 text-gray-400" />
                                        <button onClick={() => onViewPublicProfile(member)} className="text-gray-200 hover:underline">{member.name}</button>
                                        {member.userId === profile.userId && <span className="text-xs font-bold text-cyan-400">(You)</span>}
                                    </div>
                                    {profile.role === 'coach' && profile.teamId === team.id && (
                                        <button onClick={() => onViewPlayerStats(member)} className="text-xs flex items-center gap-1.5 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-1 px-3 rounded-md transition-colors">
                                            <ChartBarIcon className="w-4 h-4"/>
                                            View Stats
                                        </button>
                                    )}
                                </div>
                                {profile.role === 'coach' && profile.teamId === team.id && playerStats[member.userId] && (
                                    <div className="mt-2 ml-8 mr-2 p-3 bg-gray-900/40 rounded-lg border border-gray-700">
                                        <h5 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Progress Summary</h5>
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-2 text-sm"><CalendarIcon className="w-4 h-4 text-cyan-400" /><span className="font-semibold text-gray-300">Workouts Logged:</span><span className="text-white font-bold">{playerStats[member.userId].totalWorkouts}</span></div>
                                            <div>
                                                <div className="flex items-center gap-2 text-sm font-semibold text-gray-300"><TrophyIcon className="w-4 h-4 text-amber-400" /><span>Personal Bests (Top 3):</span></div>
                                                {Object.keys(playerStats[member.userId].personalBests).length > 0 ? (
                                                    <ul className="mt-1 pl-6 space-y-1">
                                                        {Object.entries(playerStats[member.userId].personalBests).map(([exercise, best]) => (<li key={exercise} className="text-xs text-gray-400"><span className="font-medium text-gray-200">{exercise}:</span> {best.weight}kg for {best.reps} reps</li>))}
                                                    </ul>
                                                ) : <p className="pl-6 text-xs text-gray-500 italic mt-1">No personal bests recorded yet.</p>}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </li>
                        ))}
                    </ul>
                ) : <p className="text-sm text-gray-500">This team has no players yet.</p>}
            </section>
        </div>
        
        <div className="space-y-6">
             {isCoachOrPlayerMember ? (
                <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 flex flex-col h-[50vh]">
                    <h2 className="text-xl font-bold text-white mb-4 flex-shrink-0">Team Chat</h2>
                    <div ref={chatContainerRef} className="flex-grow overflow-y-auto pr-2 -mr-2 space-y-4">
                        {teamMessages.map(msg => {
                            const isSender = msg.userId === profile.userId;
                            return (
                                <div key={msg.id} className={`flex items-end gap-2 ${isSender ? 'justify-end' : ''}`}>
                                    {!isSender && <UserIcon className="w-6 h-6 rounded-full bg-gray-700 p-1 text-gray-400 flex-shrink-0" />}
                                    <div className={`max-w-xs md:max-w-sm rounded-lg px-3 py-2 ${isSender ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-gray-700 text-gray-200 rounded-bl-none'}`}>
                                        {!isSender && <p className="text-xs font-bold text-cyan-400">{msg.userName}</p>}
                                        <p className="text-sm break-words">{msg.message}</p>
                                        <p className={`text-xs mt-1 ${isSender ? 'text-cyan-200' : 'text-gray-400'} text-right`}>{timeAgo(msg.timestamp)}</p>
                                    </div>
                                </div>
                            );
                        })}
                        {teamMessages.length === 0 && <p className="text-center text-gray-500">No messages yet. Start the conversation!</p>}
                    </div>
                    <form onSubmit={handleSendMessageSubmit} className="mt-4 flex gap-2 flex-shrink-0">
                        <input 
                            type="text"
                            value={newMessage}
                            onChange={e => setNewMessage(e.target.value)}
                            placeholder="Type a message..."
                            className="flex-grow bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                        />
                        <button type="submit" disabled={!newMessage.trim()} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold p-2.5 rounded-lg transition-colors disabled:opacity-50">
                            <SendIcon className="w-5 h-5"/>
                        </button>
                    </form>
                </section>
            ) : null}
            
            {isCurrentUserMember && (
                <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
                    <h2 className="text-xl font-bold text-white mb-4">Team Activity</h2>
                    <div className="flex gap-2 mb-4">
                        <FilterButton filter="all" label="All" />
                        <FilterButton filter="workout_plan" label="Plans" />
                        <FilterButton filter="exercise_log" label="Exercises" />
                    </div>
                    {teamActivityFeed.length > 0 ? (
                        <ul className="space-y-3 max-h-60 overflow-y-auto pr-2 -mr-2">
                           {teamActivityFeed.map((item, index) => (
                                <li key={index} className="flex items-start gap-3">
                                    <div className="flex-shrink-0 pt-1">
                                        {item.type === 'exercise_log' 
                                            ? <DumbbellIcon className="w-5 h-5 text-amber-400" />
                                            : <CalendarIcon className="w-5 h-5 text-cyan-400" />
                                        }
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-300">
                                            <button onClick={() => onViewPublicProfile(users.find(u => u.userId === item.userId)!)} className="font-bold text-white hover:underline">{item.userName}</button>
                                            {' '}
                                            {item.details}
                                        </p>
                                        <p className="text-xs text-gray-500">{timeAgo(item.timestamp)}</p>
                                    </div>
                                </li>
                           ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-center text-gray-500 pt-4">No activity to show for this filter.</p>
                    )}
                </section>
            )}

            {profile.role === 'team_organizer' && (
              <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
                <h2 className="text-xl font-bold text-white mb-4">Invite a Player</h2>
                <div className="flex flex-col sm:flex-row gap-2">
                    <div className="flex-grow">
                        <input type="email" placeholder="player@example.com" value={inviteEmail} onChange={(e) => handleInviteEmailChange(e.target.value)} className={`w-full bg-gray-700 border rounded-md py-1.5 px-3 text-white text-sm focus:ring-2 focus:outline-none placeholder-gray-500 ${inviteError ? 'border-red-500 ring-red-500/50' : 'border-gray-600 focus:ring-cyan-500 focus:border-cyan-500'}`} />
                        {inviteError && <p className="text-red-400 text-xs mt-1">{inviteError}</p>}
                    </div>
                    <button onClick={handleSendInvite} disabled={!inviteEmail || !!inviteError} className="text-sm bg-cyan-500 hover:bg-cyan-600 text-white font-semibold py-1.5 px-3 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed">Send Invite</button>
                </div>
                {(() => {
                    const pendingInvitesForTeam = invitations.filter(inv => inv.teamId === team.id);
                    if (pendingInvitesForTeam.length > 0) {
                        return (
                            <div className="mt-4 pt-4 border-t border-gray-600">
                                <h3 className="text-sm font-bold text-gray-400 uppercase mb-2">Pending Invitations</h3>
                                <ul className="space-y-1"><li key={pendingInvitesForTeam[0].email} className="text-sm text-gray-300 bg-gray-700/50 rounded px-2 py-1">{pendingInvitesForTeam[0].email}</li></ul>
                            </div>
                        );
                    }
                    return null;
                })()}
              </section>
            )}

            {profile.role === 'coach' && profile.teamId === team.id && (
                <section className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
                    <button onClick={() => setShowChallengeForm(p => !p)} className="font-bold text-xl text-white mb-2 w-full text-left flex justify-between items-center">
                       <span>Create New Challenge</span>
                       <FlagIcon className="w-6 h-6 text-cyan-400" />
                   </button>
                    {showChallengeForm && (
                        <div className="mt-4 space-y-3">
                            <input type="text" placeholder="Challenge Title (e.g., 'Max Bench Press')" value={challengeTitle} onChange={e => setChallengeTitle(e.target.value)}  className="w-full bg-gray-700 border border-gray-600 rounded-md py-1.5 px-3 text-white text-sm" />
                            <textarea placeholder="Description..." value={challengeDesc} onChange={e => setChallengeDesc(e.target.value)} rows={3} className="w-full bg-gray-700 border border-gray-600 rounded-md py-1.5 px-3 text-white text-sm" />
                            <div className="flex flex-col sm:flex-row gap-4">
                                <div>
                                    <label className="block text-xs font-medium text-gray-400 mb-1">Start Date (Optional)</label>
                                    <input type="date" value={challengeStartDate} onChange={e => setChallengeStartDate(e.target.value)} className="w-full bg-gray-700 border border-gray-600 rounded-md py-1.5 px-3 text-white text-sm" />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-400 mb-1">End Date (Optional)</label>
                                    <input type="date" value={challengeEndDate} onChange={e => setChallengeEndDate(e.target.value)} className="w-full bg-gray-700 border border-gray-600 rounded-md py-1.5 px-3 text-white text-sm" />
                                </div>
                            </div>
                            <button onClick={handleSendChallenge} disabled={!challengeTitle.trim() || !challengeDesc.trim()} className="text-sm bg-cyan-500 hover:bg-cyan-600 text-white font-semibold py-1.5 px-3 rounded-md transition-colors disabled:opacity-50">Send Challenge</button>
                        </div>
                    )}
                </section>
             )}
        </div>
      </div>
    </div>
  );
};