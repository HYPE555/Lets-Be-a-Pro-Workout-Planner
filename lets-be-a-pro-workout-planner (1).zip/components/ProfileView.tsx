import React, { useState, useEffect, useMemo } from 'react';
import { UserProfile, Team, Follow, ActivityLog } from '../types';
import { UserIcon } from './icons/UserIcon';
import { AppMode } from '../App';
import { LogoutIcon } from './icons/LogoutIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { DumbbellIcon } from './icons/DumbbellIcon';

interface ProfileViewProps {
  profile: UserProfile;
  setProfile: (profileUpdater: (prev: UserProfile) => UserProfile) => void;
  appMode: AppMode;
  teams: Team[];
  onLogout: () => void;
  follows: Follow[];
  onOpenFollowsModal: (user: UserProfile, type: 'followers' | 'following') => void;
  setToast: (toast: { message: string; type: 'success' | 'error' } | null) => void;
  activityFeed: ActivityLog[];
  users: UserProfile[];
  onViewPublicProfile: (user: UserProfile) => void;
}

const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.round((now.getTime() - date.getTime()) / 1000);
    const minutes = Math.round(seconds / 60);
    const hours = Math.round(minutes / 60);
    const days = Math.round(hours / 24);

    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
};

export const ProfileView: React.FC<ProfileViewProps> = ({ profile, setProfile, appMode, teams, onLogout, follows, onOpenFollowsModal, setToast, activityFeed, users, onViewPublicProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserProfile>(profile);

  useEffect(() => {
    setFormData(profile);
  }, [profile]);
  
  const followingIds = useMemo(() => 
    new Set(follows.filter(f => f.followerId === profile.userId).map(f => f.followingId)),
    [follows, profile.userId]
  );
        
  const feedItems = useMemo(() => 
      activityFeed.filter(activity => followingIds.has(activity.userId)).slice(0, 20), // Limit to 20 items
  [activityFeed, followingIds]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const isNumeric = ['age', 'weight', 'height'].includes(name);
    setFormData(prev => ({
      ...prev,
      [name]: isNumeric ? (value === '' ? '' : parseInt(value, 10)) : value
    }));
  };

  const handleSave = () => {
    setProfile(() => formData);
    setIsEditing(false);
    setToast({ message: "Profile updated successfully!", type: 'success' });
  };

  const handleCancel = () => {
    setFormData(profile);
    setIsEditing(false);
  };

  const currentTeamName = teams.find(team => team.id === profile.teamId)?.name;
  const followersCount = follows.filter(f => f.followingId === profile.userId).length;
  const followingCount = follows.filter(f => f.followerId === profile.userId).length;
  
  const handleViewProfileClick = (userId: string) => {
    const userToView = users.find(u => u.userId === userId);
    if(userToView) {
        onViewPublicProfile(userToView);
    }
  };

  const ProfileField: React.FC<{ label: string; value: string | number | undefined | ''; }> = ({ label, value }) => (
    <div>
      <p className="text-sm font-medium text-gray-400">{label}</p>
      <p className="text-lg text-white capitalize">{value || 'Not set'}</p>
    </div>
  );

  const InputField: React.FC<{ label: string; name: keyof Omit<UserProfile, 'role' | 'userId' | 'teamId'>; value: string | number | ''; type?: string; }> = ({ label, name, value, type = 'text' }) => (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-gray-300 mb-1">{label}</label>
      <input
        type={type}
        id={name}
        name={name}
        value={value}
        onChange={handleInputChange}
        className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
      />
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
        <div className="lg:col-span-2">
            <div className="bg-gray-800/50 rounded-2xl shadow-lg p-8 backdrop-blur-sm border border-gray-700">
            <div className="flex flex-col sm:flex-row items-center gap-6 mb-6">
                <div className="w-24 h-24 rounded-full border-4 border-gray-700 flex items-center justify-center bg-gray-700 overflow-hidden">
                    <UserIcon className="w-12 h-12 text-gray-400" />
                </div>
                <div className="flex-grow">
                    <h2 className="text-3xl font-bold text-white">{profile.name}</h2>
                    <p className="text-lg text-cyan-400 capitalize">{profile.role.replace('_', ' ')}</p>
                    <p className="text-sm text-gray-400 mt-1">{profile.email}</p>
                </div>
            </div>
            
            <div className="flex justify-center gap-8 mb-8 pb-6 border-b border-gray-700">
                <button onClick={() => onOpenFollowsModal(profile, 'followers')} className="text-center hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                <p className="text-2xl font-bold text-white">{followersCount}</p>
                <p className="text-sm text-gray-400">Followers</p>
                </button>
                <button onClick={() => onOpenFollowsModal(profile, 'following')} className="text-center hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                <p className="text-2xl font-bold text-white">{followingCount}</p>
                <p className="text-sm text-gray-400">Following</p>
                </button>
            </div>

            {isEditing ? (
                <div className="space-y-4">
                <InputField label="Name" name="name" value={formData.name} />
                <InputField label="Email" name="email" value={formData.email} type="email" />
                <InputField label="Age" name="age" value={formData.age} type="number" />
                <InputField label="Weight (kg)" name="weight" value={formData.weight} type="number" />
                <InputField label="Height (cm)" name="height" value={formData.height} type="number" />
                <div className="flex justify-end gap-4 pt-4">
                    <button onClick={handleCancel} className="px-4 py-2 rounded-lg text-gray-300 bg-gray-600 hover:bg-gray-500 transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-4 py-2 rounded-lg text-white bg-cyan-500 hover:bg-cyan-600 transition-colors font-semibold">Save Changes</button>
                </div>
                </div>
            ) : (
                <div className="space-y-6">
                {appMode === 'hockey' && profile.role !== 'team_organizer' && <ProfileField label="Team" value={currentTeamName || 'No Team'} />}
                <ProfileField label="Age" value={profile.age} />
                <ProfileField label="Weight (kg)" value={profile.weight} />
                <ProfileField label="Height (cm)" value={profile.height} />
                <div className="flex justify-end items-center gap-4 pt-4">
                    <button 
                        onClick={onLogout} 
                        className="flex items-center gap-2 px-4 py-2 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors font-semibold"
                    >
                        <LogoutIcon className="w-5 h-5" />
                        Logout
                    </button>
                    <button onClick={() => setIsEditing(true)} className="px-6 py-2 rounded-lg text-white bg-gray-700 hover:bg-gray-600 transition-colors font-semibold">Edit Details</button>
                </div>
                </div>
            )}
            </div>
        </div>
        <div className="lg:col-span-1">
            <div className="bg-gray-800/50 rounded-2xl shadow-lg p-6 backdrop-blur-sm border border-gray-700 h-full">
                <h3 className="text-xl font-bold text-white mb-4">Social Feed</h3>
                {feedItems.length > 0 ? (
                    <ul className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 -mr-2">
                        {feedItems.map((item, index) => (
                            <li key={index} className="flex items-start gap-3">
                                <div className="flex-shrink-0 pt-1">
                                    {item.type === 'exercise_log' 
                                        ? <DumbbellIcon className="w-5 h-5 text-amber-400" />
                                        : <CalendarIcon className="w-5 h-5 text-cyan-400" />
                                    }
                                </div>
                                <div>
                                    <p className="text-sm text-gray-300">
                                        <button onClick={() => handleViewProfileClick(item.userId)} className="font-bold text-white hover:underline">{item.userName}</button>
                                        {' '}
                                        {item.details}
                                    </p>
                                    <p className="text-xs text-gray-500">{timeAgo(item.timestamp)}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="text-center text-gray-500 pt-8">
                        <p>Follow other users to see their activity here!</p>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};