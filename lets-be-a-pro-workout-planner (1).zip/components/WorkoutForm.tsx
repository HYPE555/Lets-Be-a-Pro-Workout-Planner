
import React, { useState, useEffect } from 'react';
import { WorkoutPreferences, Day, FitnessLevel } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { searchExercises } from '../services/geminiService';
import { SearchIcon } from './icons/SearchIcon';
import { XCircleIcon } from './icons/XCircleIcon';
import { AppMode } from '../App';


interface WorkoutFormProps {
  preferences: WorkoutPreferences;
  setPreferences: React.Dispatch<React.SetStateAction<WorkoutPreferences>>;
  onSubmit: () => void;
  isLoading: boolean;
  appMode: AppMode;
}

const generalGoalsOptions = ["Build Muscle", "Lose Weight", "Improve Endurance", "General Fitness", "Increase Flexibility"];
const hockeyGoalsOptions = ["Improve Shot Power", "Increase Skating Speed", "On-Ice Endurance", "Injury Prevention", "Stickhandling Strength"];

const equipmentOptions = ["Dumbbells", "Barbell", "Kettlebell", "Resistance Bands", "Pull-up Bar", "Bodyweight Only"];
const daysOptions: Day[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export const WorkoutForm: React.FC<WorkoutFormProps> = ({ preferences, setPreferences, onSubmit, isLoading, appMode }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ name: string; description: string }[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const goalsOptions = appMode === 'hockey' ? hockeyGoalsOptions : generalGoalsOptions;
  
  // Clear goals when app mode changes
  useEffect(() => {
    setPreferences(prev => ({...prev, goals: []}));
  }, [appMode, setPreferences]);

  useEffect(() => {
    // Clear results if query is short
    if (searchQuery.length < 3) {
      setSearchResults([]);
      if (isSearching) setIsSearching(false);
      return;
    }

    const handler = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchExercises(searchQuery);
        setSearchResults(results);
      } catch (error) {
        console.error("Exercise search failed:", error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 500); // 500ms debounce

    return () => {
      clearTimeout(handler);
    };
  }, [searchQuery]);


  const handleMultiSelectChange = (field: 'goals' | 'equipment' | 'availableDays', value: string) => {
    setPreferences(prev => {
      const currentValues = prev[field] as string[];
      if (currentValues.includes(value)) {
        return { ...prev, [field]: currentValues.filter(item => item !== value) };
      } else {
        return { ...prev, [field]: [...currentValues, value] };
      }
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPreferences(prev => ({ ...prev, [name]: value }));
  };

  const handleAddCustomExercise = (exercise: { name: string }) => {
    setPreferences(prev => {
        const currentExercises = prev.customExercises || [];
        // Prevent duplicates
        if (!currentExercises.some(ex => ex.name.toLowerCase() === exercise.name.toLowerCase())) {
            return { ...prev, customExercises: [...currentExercises, exercise] };
        }
        return prev;
    });
    setSearchQuery('');
    setSearchResults([]);
  };

  const handleRemoveCustomExercise = (exerciseName: string) => {
      setPreferences(prev => ({
          ...prev,
          customExercises: (prev.customExercises || []).filter(ex => ex.name !== exerciseName)
      }));
  };

  return (
    <div className="bg-gray-800/50 rounded-2xl shadow-lg p-6 backdrop-blur-sm border border-gray-700">
      <h2 className="text-2xl font-bold mb-6 text-white">Your Fitness Profile</h2>
      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-6">
        
        {/* Goals */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">What are your goals?</label>
          <div className="grid grid-cols-2 gap-2">
            {goalsOptions.map(goal => (
              <button
                key={goal}
                type="button"
                onClick={() => handleMultiSelectChange('goals', goal)}
                className={`text-sm py-2 px-3 rounded-lg transition-all duration-200 ${preferences.goals.includes(goal) ? 'bg-cyan-500 text-white font-semibold shadow-md' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}
              >
                {goal}
              </button>
            ))}
          </div>
        </div>

        {/* Fitness Level */}
        <div>
          <label htmlFor="fitnessLevel" className="block text-sm font-medium text-gray-300 mb-2">Fitness Level</label>
          <select
            id="fitnessLevel"
            name="fitnessLevel"
            value={preferences.fitnessLevel}
            onChange={handleInputChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
          >
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>

        {/* Available Days */}
        <div>
           <label className="block text-sm font-medium text-gray-300 mb-2">Which days can you work out?</label>
           <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {daysOptions.map(day => (
              <button
                key={day}
                type="button"
                onClick={() => handleMultiSelectChange('availableDays', day)}
                className={`text-sm py-2 px-3 rounded-lg transition-all duration-200 ${preferences.availableDays.includes(day) ? 'bg-cyan-500 text-white font-semibold shadow-md' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}
              >
                {day.substring(0,3)}
              </button>
            ))}
          </div>
        </div>

        {/* Workout Duration */}
        <div>
            <label htmlFor="duration" className="block text-sm font-medium text-gray-300 mb-2">Preferred Workout Duration</label>
            <select
                id="duration"
                name="duration"
                value={preferences.duration}
                onChange={handleInputChange}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
            >
                <option value="30">30 minutes</option>
                <option value="45">45 minutes</option>
                <option value="60">60 minutes</option>
                <option value="90">90 minutes</option>
            </select>
        </div>

        {/* Equipment */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">What equipment do you have?</label>
          <div className="grid grid-cols-2 gap-2">
            {equipmentOptions.map(eq => (
              <button
                key={eq}
                type="button"
                onClick={() => handleMultiSelectChange('equipment', eq)}
                className={`text-sm py-2 px-3 rounded-lg transition-all duration-200 ${preferences.equipment.includes(eq) ? 'bg-cyan-500 text-white font-semibold shadow-md' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}
              >
                {eq}
              </button>
            ))}
          </div>
        </div>
        
        {/* Custom Exercises */}
        <div>
          <label htmlFor="exerciseSearch" className="block text-sm font-medium text-gray-300 mb-2">Add Specific Exercises</label>
          <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <SearchIcon className="w-5 h-5 text-gray-400" />
              </div>
              <input
                  type="text"
                  id="exerciseSearch"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="e.g., 'Bench Press' or 'Leg workouts'"
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 pl-10 pr-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 placeholder-gray-500"
              />
          </div>

          {isSearching && <p className="text-sm text-gray-400 mt-2 animate-pulse">Searching for exercises...</p>}

          {searchResults.length > 0 && !isSearching && (
              <div className="mt-2 bg-gray-900/50 border border-gray-700 rounded-lg max-h-60 overflow-y-auto shadow-lg">
                  <ul className="divide-y divide-gray-700">
                      {searchResults.map((ex, index) => (
                          <li key={index} className="px-4 py-3 flex justify-between items-center group hover:bg-gray-800/50 transition-colors">
                              <div>
                                  <p className="font-semibold text-white text-sm">{ex.name}</p>
                                  <p className="text-xs text-gray-400">{ex.description}</p>
                              </div>
                              <button
                                  type="button"
                                  onClick={() => handleAddCustomExercise({ name: ex.name })}
                                  className="text-xs bg-cyan-500 hover:bg-cyan-600 text-white font-semibold py-1 px-3 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                                  aria-label={`Add ${ex.name}`}
                              >
                                  Add
                              </button>
                          </li>
                      ))}
                  </ul>
              </div>
          )}

          {(preferences.customExercises && preferences.customExercises.length > 0) && (
              <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-300 mb-2">Added Exercises:</h4>
                  <div className="flex flex-wrap gap-2">
                      {preferences.customExercises.map((ex, index) => (
                          <div key={index} className="flex items-center gap-2 bg-gray-700 rounded-full px-3 py-1 text-sm text-white">
                              <span>{ex.name}</span>
                              <button
                                  type="button"
                                  onClick={() => handleRemoveCustomExercise(ex.name)}
                                  className="text-gray-400 hover:text-white"
                                  aria-label={`Remove ${ex.name}`}
                              >
                                  <XCircleIcon className="w-4 h-4" />
                              </button>
                          </div>
                      ))}
                  </div>
              </div>
          )}
        </div>


        {/* Additional Notes */}
        <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-300 mb-2">Anything else to add?</label>
            <textarea
                id="notes"
                name="notes"
                rows={3}
                value={preferences.notes}
                onChange={handleInputChange}
                placeholder="e.g., 'I have a sensitive left knee' or 'Focus on off-season training'"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 placeholder-gray-500"
            />
        </div>
        
        {/* Submit Button */}
        <div>
          <button
            type="submit"
            disabled={isLoading || preferences.goals.length === 0 || preferences.availableDays.length === 0}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
          >
            <SparklesIcon className="w-5 h-5" />
            {isLoading ? 'Generating Plan...' : 'Generate My Plan'}
          </button>
        </div>
      </form>
    </div>
  );
};
