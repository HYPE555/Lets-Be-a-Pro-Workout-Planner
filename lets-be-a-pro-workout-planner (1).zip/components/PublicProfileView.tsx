import React from 'react';
import { UserProfile, Team, Follow } from '../types';
import { UserIcon } from './icons/UserIcon';
import { CloseIcon } from './icons/CloseIcon';
import { UserPlusIcon } from './icons/UserPlusIcon';

interface PublicProfileViewProps {
  user: UserProfile;
  currentUser: UserProfile;
  users: UserProfile[];
  teams: Team[];
  follows: Follow[];
  onClose: () => void;
  onFollow: (userId: string) => void;
  onUnfollow: (userId: string) => void;
  onOpenFollowsModal: (user: UserProfile, type: 'followers' | 'following') => void;
}

export const PublicProfileView: React.FC<PublicProfileViewProps> = ({ user, currentUser, users, teams, follows, onClose, onFollow, onUnfollow, onOpenFollowsModal }) => {
  const teamName = teams.find(t => t.id === user.teamId)?.name || 'No Team';
  const followersCount = follows.filter(f => f.followingId === user.userId).length;
  const followingCount = follows.filter(f => f.followerId === user.userId).length;
  const isFollowing = follows.some(f => f.followerId === currentUser.userId && f.followingId === user.userId);
  const isSelf = user.userId === currentUser.userId;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-gray-800 rounded-2xl p-8 border border-gray-700 shadow-xl max-w-sm w-full mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-white">User Profile</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
                <CloseIcon className="w-6 h-6" />
            </button>
        </div>
        
        <div className="flex flex-col items-center gap-4 mb-6">
            <div className="w-24 h-24 rounded-full border-4 border-gray-700 flex items-center justify-center bg-gray-700">
                <UserIcon className="w-12 h-12 text-gray-400" />
            </div>
            <div>
                <h3 className="text-2xl font-bold text-white text-center">{user.name}</h3>
                <p className="text-md text-cyan-400 capitalize text-center">{user.role.replace('_', ' ')}</p>
                {user.teamId && <p className="text-sm text-gray-400 text-center mt-1">Team: {teamName}</p>}
            </div>
        </div>

        <div className="flex justify-center gap-8 mb-6 pb-6 border-b border-gray-700">
            <button onClick={() => onOpenFollowsModal(user, 'followers')} className="text-center hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                <p className="text-xl font-bold text-white">{followersCount}</p>
                <p className="text-sm text-gray-400">Followers</p>
            </button>
            <button onClick={() => onOpenFollowsModal(user, 'following')} className="text-center hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                <p className="text-xl font-bold text-white">{followingCount}</p>
                <p className="text-sm text-gray-400">Following</p>
            </button>
        </div>

        {!isSelf && (
            isFollowing ? (
                <button 
                    onClick={() => onUnfollow(user.userId)} 
                    className="w-full bg-gray-600 hover:bg-gray-500 text-white font-bold py-2.5 px-4 rounded-lg transition-colors"
                >
                    Unfollow
                </button>
            ) : (
                <button 
                    onClick={() => onFollow(user.userId)} 
                    className="w-full flex items-center justify-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2.5 px-4 rounded-lg transition-colors"
                >
                    <UserPlusIcon className="w-5 h-5" />
                    Follow
                </button>
            )
        )}
      </div>
    </div>
  );
};
