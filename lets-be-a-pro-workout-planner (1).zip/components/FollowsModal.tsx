import React from 'react';
import { UserProfile, Follow } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { UserIcon } from './icons/UserIcon';
import { UserPlusIcon } from './icons/UserPlusIcon';

interface FollowsModalProps {
  modalData: { user: UserProfile; type: 'followers' | 'following' };
  currentUser: UserProfile;
  users: UserProfile[];
  follows: Follow[];
  onClose: () => void;
  onFollow: (userId: string) => void;
  onUnfollow: (userId: string) => void;
  onViewProfile: (user: UserProfile) => void;
}

export const FollowsModal: React.FC<FollowsModalProps> = ({ modalData, currentUser, users, follows, onClose, onFollow, onUnfollow, onViewProfile }) => {
  const { user, type } = modalData;

  const userIds = type === 'followers'
    ? follows.filter(f => f.followingId === user.userId).map(f => f.followerId)
    : follows.filter(f => f.followerId === user.userId).map(f => f.followingId);
  
  const userList = users.filter(u => userIds.includes(u.userId));

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-xl max-w-md w-full mx-4 flex flex-col" style={{ height: '70vh' }} onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4 flex-shrink-0">
          <h2 className="text-xl font-bold text-white capitalize">{type}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        
        <div className="overflow-y-auto pr-2 -mr-2">
          {userList.length > 0 ? (
            <ul className="space-y-3">
              {userList.map(listUser => {
                const isCurrentUserFollowing = follows.some(f => f.followerId === currentUser.userId && f.followingId === listUser.userId);
                const isSelf = listUser.userId === currentUser.userId;

                return (
                  <li key={listUser.userId} className="flex items-center justify-between gap-3 p-2 rounded-lg hover:bg-gray-700/50">
                    <button onClick={() => onViewProfile(listUser)} className="flex items-center gap-3 text-left">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-700">
                        <UserIcon className="w-6 h-6 text-gray-400" />
                      </div>
                      <div>
                        <p className="font-bold text-white">{listUser.name}</p>
                        <p className="text-sm text-gray-400 capitalize">{listUser.role.replace('_', ' ')}</p>
                      </div>
                    </button>
                    {!isSelf && (
                      isCurrentUserFollowing ? (
                        <button 
                          onClick={() => onUnfollow(listUser.userId)}
                          className="text-xs bg-gray-600 hover:bg-gray-500 text-white font-semibold py-1.5 px-3 rounded-md transition-colors"
                        >
                          Unfollow
                        </button>
                      ) : (
                        <button 
                          onClick={() => onFollow(listUser.userId)}
                          className="text-xs flex items-center gap-1 bg-cyan-500 hover:bg-cyan-600 text-white font-semibold py-1.5 px-3 rounded-md transition-colors"
                        >
                           <UserPlusIcon className="w-4 h-4" />
                           Follow
                        </button>
                      )
                    )}
                  </li>
                );
              })}
            </ul>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <p>No users to display.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
