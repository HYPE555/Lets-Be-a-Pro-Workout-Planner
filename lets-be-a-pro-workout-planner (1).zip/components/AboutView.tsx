import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { DumbbellIcon } from './icons/DumbbellIcon';
import { HockeyIcon } from './icons/HockeyIcon';
import { UsersIcon } from './icons/UsersIcon';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto bg-gray-800/50 rounded-2xl shadow-lg p-8 backdrop-blur-sm border border-gray-700 animate-fade-in text-gray-300 leading-relaxed">
      <div className="text-center mb-8">
        <SparklesIcon className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">
          About AI Workout Planner
        </h1>
        <p className="mt-4 text-lg text-gray-400">
          Your intelligent partner in achieving peak physical performance.
        </p>
      </div>

      <div className="space-y-8">
        <section>
          <h2 className="text-2xl font-semibold text-white mb-3">How It Works</h2>
          <p>
            The magic behind your plan is <span className="font-semibold text-cyan-400">Google's Gemini model</span>. When you provide your goals, fitness level, available equipment, and schedule, our app communicates with this powerful AI. Gemini processes your unique requirements and crafts a comprehensive, week-long workout plan, complete with exercises, sets, reps, warm-ups, and cool-downs—just like a real personal trainer would.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mb-3">Key Features</h2>
          <ul className="space-y-4">
            <li className="flex items-start gap-4">
              <div className="flex-shrink-0 pt-1">
                <DumbbellIcon className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white">Personalized Plans</h3>
                <p className="text-gray-400">From general fitness to sport-specific training like hockey, get plans that align perfectly with your ambitions.</p>
              </div>
            </li>
            <li className="flex items-start gap-4">
               <div className="flex-shrink-0 pt-1">
                <UsersIcon className="w-6 h-6 text-teal-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white">Team & Community</h3>
                <p className="text-gray-400">Join teams, follow fellow athletes, and engage with a community. Coaches and organizers can manage rosters, track player progress, and issue team-wide challenges.</p>
              </div>
            </li>
            <li className="flex items-start gap-4">
               <div className="flex-shrink-0 pt-1">
                <HockeyIcon className="w-6 h-6 text-rose-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white">Progress Tracking</h3>
                <p className="text-gray-400">Log your performance for each exercise and visualize your strength gains over time with interactive charts.</p>
              </div>
            </li>
          </ul>
        </section>
        
        <div className="text-center pt-6 border-t border-gray-700">
            <p className="text-gray-500">
                Let's build a stronger you, together.
            </p>
        </div>

      </div>
    </div>
  );
};