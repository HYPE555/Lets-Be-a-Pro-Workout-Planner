import React from 'react';
import { WorkoutPreferences, FitnessLevel } from '../types';
import { FilterIcon } from './icons/FilterIcon';

const goalsOptions = ["Build Muscle", "Lose Weight", "Improve Endurance", "General Fitness", "Increase Flexibility"];
const equipmentOptions = ["Dumbbells", "Barbell", "Kettlebell", "Resistance Bands", "Pull-up Bar", "Bodyweight Only"];

interface PlanFiltersProps {
  preferences: WorkoutPreferences;
  setPreferences: React.Dispatch<React.SetStateAction<WorkoutPreferences>>;
}

export const PlanFilters: React.FC<PlanFiltersProps> = ({ preferences, setPreferences }) => {

  const handleFitnessLevelChange = (level: FitnessLevel) => {
    setPreferences(prev => ({ ...prev, fitnessLevel: level }));
  };

  const handleGoalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPreferences(prev => ({ ...prev, goals: [e.target.value] }));
  };
  
  const handleEquipmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
     setPreferences(prev => ({ ...prev, equipment: [e.target.value] }));
  };

  return (
    <div className="bg-gray-800/60 rounded-xl shadow-md p-4 mb-6 backdrop-blur-sm border border-gray-700 animate-fade-in">
      <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
        <FilterIcon className="w-5 h-5 text-cyan-400" />
        Quick Filters
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Fitness Level */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Fitness Level</label>
          <div className="flex bg-gray-700 rounded-lg p-1">
            {(['beginner', 'intermediate', 'advanced'] as FitnessLevel[]).map(level => (
              <button
                key={level}
                onClick={() => handleFitnessLevelChange(level)}
                className={`w-full capitalize text-sm py-1.5 px-2 rounded-md transition-all duration-200 ${preferences.fitnessLevel === level ? 'bg-cyan-500 text-white font-semibold shadow' : 'text-gray-200 hover:bg-gray-600'}`}
              >
                {level}
              </button>
            ))}
          </div>
        </div>

        {/* Main Goal */}
        <div>
          <label htmlFor="goalFilter" className="block text-sm font-medium text-gray-300 mb-2">Main Goal</label>
          <select
            id="goalFilter"
            name="goalFilter"
            value={preferences.goals[0] || ''}
            onChange={handleGoalChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
          >
            {goalsOptions.map(goal => (
              <option key={goal} value={goal}>{goal}</option>
            ))}
          </select>
        </div>

        {/* Equipment */}
        <div>
          <label htmlFor="equipmentFilter" className="block text-sm font-medium text-gray-300 mb-2">Equipment</label>
           <select
            id="equipmentFilter"
            name="equipmentFilter"
            value={preferences.equipment[0] || ''}
            onChange={handleEquipmentChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
          >
            {equipmentOptions.map(eq => (
              <option key={eq} value={eq}>{eq}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};