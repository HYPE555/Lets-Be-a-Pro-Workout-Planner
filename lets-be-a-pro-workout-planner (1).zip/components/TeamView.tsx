import React, { useState } from 'react';
import { Team, UserProfile } from '../types';
import { UsersIcon } from './icons/UsersIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { SearchIcon } from './icons/SearchIcon';

interface TeamViewProps {
  teams: Team[];
  setTeams: React.Dispatch<React.SetStateAction<Team[]>>;
  profile: UserProfile;
  setProfile: (profileUpdater: (prev: UserProfile) => UserProfile) => void;
  users: UserProfile[];
  setToast: (toast: { message: string; type: 'success' | 'error' } | null) => void;
  onViewTeamPage: (team: Team) => void;
}

export const TeamView: React.FC<TeamViewProps> = ({ teams, setTeams, profile, setProfile, users, setToast, onViewTeamPage }) => {
  const [newTeamName, setNewTeamName] = useState('');
  const [showCreateConfirm, setShowCreateConfirm] = useState(false);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const userRole = profile.role;
  const canCreateTeam = userRole === 'team_organizer' || userRole === 'coach';
  const currentTeam = teams.find(t => t.id === profile.teamId);

  const filteredTeams = teams.filter(team => 
    team.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    team.joinCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateTeamSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTeamName.trim() && canCreateTeam) {
      setShowCreateConfirm(true);
    }
  };
  
  const confirmCreateTeam = () => {
    if (!canCreateTeam || !newTeamName.trim()) return;
    
    const teamName = newTeamName.trim();
    const codePrefix = teamName.replace(/[^a-zA-Z]/g, '').substring(0, 4).toUpperCase();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);

    const newTeam: Team = {
      id: crypto.randomUUID(),
      name: teamName,
      joinCode: `${codePrefix}-${randomSuffix}`,
    };

    setTeams(prev => [...prev, newTeam]);
    setNewTeamName('');
    setShowCreateConfirm(false);
    setToast({ message: `Team "${teamName}" created successfully!`, type: 'success' });
  };

  const handleJoinWithCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCodeInput.trim()) {
        setToast({ message: "Please enter a team code.", type: 'error' });
        return;
    }
    const code = joinCodeInput.trim().toUpperCase();
    const teamToJoin = teams.find(t => t.joinCode.toUpperCase() === code);

    if (teamToJoin) {
        setProfile(prev => ({ ...prev, teamId: teamToJoin.id }));
        setToast({ message: `Successfully joined ${teamToJoin.name}!`, type: 'success' });
        setJoinCodeInput('');
    } else {
        setToast({ message: "Invalid team code. Please check the code and try again.", type: 'error' });
    }
  };
  
  const confirmLeaveTeam = () => {
    if (userRole === 'player' || userRole === 'coach') {
      const teamName = currentTeam?.name;
      setProfile(prev => {
        const { teamId, ...rest } = prev;
        return rest;
      });
      setToast({ message: `You have successfully left ${teamName}.`, type: 'success' });
    }
    setShowLeaveConfirm(false);
  };

  const isCoachLeaving = userRole === 'coach';
  const leaveModalTitle = isCoachLeaving ? 'Confirm Stop Coaching' : 'Confirm Leave Team';
  const leaveModalText = isCoachLeaving
      ? `Are you sure you want to stop coaching "${currentTeam?.name}"?`
      : `Are you sure you want to leave "${currentTeam?.name}"?`;
  const leaveModalButtonText = isCoachLeaving ? 'Stop Coaching' : 'Leave';

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
       {/* Confirmation Modals */}
      {showCreateConfirm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 shadow-xl">
            <h3 className="text-lg font-bold text-white">Confirm Team Creation</h3>
            <p className="text-gray-400 mt-2">Are you sure you want to create the team "{newTeamName}"?</p>
            <div className="flex justify-end gap-4 mt-6">
              <button onClick={() => setShowCreateConfirm(false)} className="px-4 py-2 rounded-lg text-gray-300 bg-gray-600 hover:bg-gray-500">Cancel</button>
              <button onClick={confirmCreateTeam} className="px-4 py-2 rounded-lg text-white bg-cyan-500 hover:bg-cyan-600 font-semibold">Confirm</button>
            </div>
          </div>
        </div>
      )}
      {showLeaveConfirm && (
         <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 shadow-xl">
            <h3 className="text-lg font-bold text-white">{leaveModalTitle}</h3>
            <p className="text-gray-400 mt-2">{leaveModalText}</p>
            <div className="flex justify-end gap-4 mt-6">
              <button onClick={() => setShowLeaveConfirm(false)} className="px-4 py-2 rounded-lg text-gray-300 bg-gray-600 hover:bg-gray-500">Cancel</button>
              <button onClick={confirmLeaveTeam} className="px-4 py-2 rounded-lg text-white bg-red-500 hover:bg-red-600 font-semibold">{leaveModalButtonText}</button>
            </div>
          </div>
        </div>
      )}

      {canCreateTeam && (
        <section className="bg-gray-800/50 rounded-2xl shadow-lg p-6 backdrop-blur-sm border border-gray-700">
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-3">
              <UsersIcon className="w-6 h-6 text-cyan-400" />
              Create a New Team
          </h2>
          <form onSubmit={handleCreateTeamSubmit} className="flex flex-col sm:flex-row gap-4">
            <label htmlFor="new-team-name" className="sr-only">Team Name</label>
            <input
              id="new-team-name"
              type="text"
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              placeholder="Enter your team name..."
              className="flex-grow bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 placeholder-gray-500"
            />
            <button
              type="submit"
              disabled={!newTeamName.trim()}
              className="flex items-center justify-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2.5 px-4 rounded-lg shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <PlusCircleIcon className="w-5 h-5" />
              Create Team
            </button>
          </form>
        </section>
      )}

      {currentTeam && (
          <section className="text-center bg-gray-800/50 rounded-2xl p-6 border border-cyan-500/30">
              <p className="text-gray-300">
                {userRole === 'player' ? 'You are on team:' : 'You are coaching:'}
              </p>
              <h2 className="text-3xl font-bold text-cyan-400 my-2">{currentTeam.name}</h2>
              <button onClick={() => setShowLeaveConfirm(true)} className="mt-4 text-sm text-red-400 hover:text-red-300 hover:underline">
                {userRole === 'player' ? 'Leave Team' : 'Stop Coaching'}
              </button>
          </section>
      )}

      {userRole === 'player' && !currentTeam && (
            <section className="bg-gray-800/50 rounded-2xl shadow-lg p-6 backdrop-blur-sm border border-gray-700">
              <h2 className="text-2xl font-bold text-white mb-4">Join a Team</h2>
              <p className="text-gray-400 mb-4">Enter the unique join code provided by your coach or team organizer.</p>
              <form onSubmit={handleJoinWithCode} className="flex flex-col sm:flex-row gap-4">
                  <label htmlFor="join-code" className="sr-only">Join Code</label>
                  <input
                    id="join-code"
                    type="text"
                    value={joinCodeInput}
                    onChange={(e) => setJoinCodeInput(e.target.value)}
                    placeholder="e.g., DRGN-1234"
                    className="flex-grow bg-gray-700 border border-gray-600 rounded-lg py-2 px-3 text-white uppercase focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 placeholder-gray-500"
                  />
                  <button
                    type="submit"
                    className="flex items-center justify-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2.5 px-4 rounded-lg shadow-lg transition-colors"
                  >
                    Join with Code
                  </button>
              </form>
            </section>
      )}

      <section>
        <h2 className="text-3xl font-bold text-white text-center mb-6">
            Discover Teams
        </h2>
        
        <div className="mb-6 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="w-5 h-5 text-gray-400" />
            </div>
            <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for a team by name or code..."
                className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2.5 pl-10 pr-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 placeholder-gray-500"
            />
        </div>

         {userRole === 'coach' && !currentTeam && (
            <div className="mb-6 text-center bg-gray-800/50 rounded-2xl p-4 border border-cyan-500/30">
                <p className="text-gray-300 text-sm">You are not currently coaching a team. Select a team to begin.</p>
            </div>
        )}
        <div className="space-y-3">
          {filteredTeams.length > 0 ? (
            filteredTeams.map(team => {
              const members = users.filter(u => u.teamId === team.id && u.role === 'player');
              return (
                <button
                    key={team.id}
                    onClick={() => onViewTeamPage(team)}
                    className="w-full text-left bg-gray-800 rounded-lg border border-gray-700 overflow-hidden p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:bg-gray-700/50 transition-colors"
                >
                    <div className="flex-grow">
                        <div className="flex items-center gap-3">
                        <p className="font-semibold text-white text-lg">{team.name}</p>
                        <span className="text-sm font-medium text-gray-300 bg-gray-700/50 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                            <UsersIcon className="w-4 h-4 text-cyan-400" />
                            {members.length}
                        </span>
                        </div>
                        <p className="font-mono text-sm text-cyan-300 tracking-wider mt-1">{team.joinCode}</p>
                    </div>

                    <div className="flex-shrink-0 flex items-center gap-2 text-cyan-400 font-semibold text-sm">
                        <span>View Details</span>
                        <span className="transition-transform group-hover:translate-x-1">&rarr;</span>
                    </div>
                </button>
              )
            })
          ) : (
             <div className="text-center text-gray-500 bg-gray-800/50 rounded-2xl p-8 border border-gray-700">
                <p>No teams found matching your search.</p>
                {searchQuery === '' && canCreateTeam && <p>Use the form above to create the first one!</p>}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};