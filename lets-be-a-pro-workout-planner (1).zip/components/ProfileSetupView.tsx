
import React, { useState } from 'react';
import { UserProfile, UserRole, Invitation } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { DumbbellIcon } from './icons/DumbbellIcon';
import { UsersIcon } from './icons/UsersIcon';
import { ClipboardIcon } from './icons/ClipboardIcon'; // A generic icon for organizer

interface ProfileSetupViewProps {
  onProfileCreate: (profile: UserProfile) => void;
  onBackToLogin: () => void;
  invitations: Invitation[];
}

const RoleCard: React.FC<{ role: UserRole, label: string, description: string, icon: React.ReactNode, isSelected: boolean, onSelect: () => void }> = 
({ role, label, description, icon, isSelected, onSelect }) => (
    <button
        type="button"
        onClick={onSelect}
        className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ${isSelected ? 'bg-cyan-900/50 border-cyan-500 shadow-lg' : 'bg-gray-700 border-gray-600 hover:border-gray-500'}`}
    >
        <div className="flex items-center gap-4">
            <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-gray-800 rounded-full">
                {icon}
            </div>
            <div>
                <h3 className="font-bold text-white">{label}</h3>
                <p className="text-sm text-gray-400">{description}</p>
            </div>
        </div>
    </button>
);


export const ProfileSetupView: React.FC<ProfileSetupViewProps> = ({ onProfileCreate, onBackToLogin, invitations }) => {
  const [formData, setFormData] = useState<Omit<UserProfile, 'userId' | 'role' | 'teamId'>>({
    name: '',
    email: '',
    age: '',
    weight: '',
    height: '',
  });
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [formErrors, setFormErrors] = useState<{ email?: string }>({});

  const pendingInvite = invitations.find(inv => inv.email.toLowerCase() === formData.email.toLowerCase());

  const validateEmail = (email: string) => {
    if (!email) return "Email is required.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Invalid email format.";
    return "";
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    setFormData(prev => {
        const isNumeric = ['age', 'weight', 'height'].includes(name);
        const newValue = isNumeric ? (value === '' ? '' : parseInt(value, 10)) : value;
        const newFormData = {...prev, [name]: newValue };

        if (name === 'email') {
            const error = validateEmail(value);
            setFormErrors(prevErrors => ({...prevErrors, email: error}));
        }

        return newFormData;
    });
  };

  const handleSave = () => {
    const emailError = validateEmail(formData.email);
    if (formData.name.trim() && selectedRole && formData.email && !emailError) {
      onProfileCreate({
        ...formData,
        userId: crypto.randomUUID(),
        role: selectedRole,
      });
    } else {
        setFormErrors({ email: emailError });
    }
  };
  
  const InputField: React.FC<{ label: string; name: keyof typeof formData; value: string | number; type?: string; placeholder: string; isRequired?: boolean; error?: string; }> = ({ label, name, value, type = 'text', placeholder, isRequired = false, error }) => (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-gray-300 mb-1">{label} {isRequired && <span className="text-red-400">*</span>}</label>
      <input
        type={type}
        id={name}
        name={name}
        value={value}
        onChange={handleInputChange}
        placeholder={placeholder}
        className={`w-full bg-gray-700 border rounded-lg py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 placeholder-gray-500 ${error ? 'border-red-500 focus:border-red-500' : 'border-gray-600 focus:border-cyan-500'}`}
      />
      {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 text-gray-100 p-4 animate-fade-in">
      <div className="max-w-md w-full text-center bg-gray-800/50 rounded-2xl shadow-lg p-8 backdrop-blur-sm border border-gray-700">
        <div className="flex items-center justify-center gap-4 mb-4">
          <SparklesIcon className="w-10 h-10 text-cyan-400" />
          <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">
            Create Account
          </h1>
        </div>
        <p className="mt-2 mb-8 text-lg text-gray-400">
          First, choose your role, then fill out your details.
        </p>
        
        <div className="space-y-4 text-left">
           <div className="space-y-3">
             <label className="block text-sm font-medium text-gray-300 mb-1">Select Your Role <span className="text-red-400">*</span></label>
             <RoleCard 
                role="player"
                label="Player"
                description="Get personalized workout plans and track your progress."
                icon={<DumbbellIcon className="w-6 h-6 text-cyan-400"/>}
                isSelected={selectedRole === 'player'}
                onSelect={() => setSelectedRole('player')}
             />
             <RoleCard 
                role="coach"
                label="Coach"
                description="View team rosters and monitor player activity."
                icon={<UsersIcon className="w-6 h-6 text-cyan-400"/>}
                isSelected={selectedRole === 'coach'}
                onSelect={() => setSelectedRole('coach')}
             />
             <RoleCard 
                role="team_organizer"
                label="Team Organizer"
                description="Create and manage teams for players and coaches."
                icon={<ClipboardIcon className="w-6 h-6 text-cyan-400"/>}
                isSelected={selectedRole === 'team_organizer'}
                onSelect={() => setSelectedRole('team_organizer')}
             />
           </div>

           <InputField label="Name" name="name" value={formData.name} placeholder="Enter your name" isRequired />
           <InputField label="Email" name="email" value={formData.email} placeholder="Enter your email" type="email" isRequired error={formErrors.email} />
            {pendingInvite && !formErrors.email && (
                <div className="bg-cyan-900/50 border border-cyan-700 text-cyan-200 text-sm rounded-md p-3 text-center">
                    You have a pending invitation to a team! Create your account to accept it.
                </div>
            )}
           <InputField label="Age" name="age" value={formData.age} type="number" placeholder="e.g., 25" />
           <InputField label="Weight (kg)" name="weight" value={formData.weight} type="number" placeholder="e.g., 70" />
           <InputField label="Height (cm)" name="height" value={formData.height} type="number" placeholder="e.g., 180" />
        </div>

        <div className="mt-8 flex flex-col gap-4">
            <button 
                onClick={handleSave} 
                disabled={!formData.name.trim() || !selectedRole || !formData.email || !!formErrors.email}
                className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
            >
                Create Account & Login
            </button>

            <button
                onClick={onBackToLogin}
                className="text-sm text-gray-400 hover:text-white hover:underline transition-colors"
            >
                Back to Login
            </button>
        </div>
      </div>
    </div>
  );
};
