import React from 'react';
import { Notification } from '../types';
import { FlagIcon } from './icons/FlagIcon';
import { UserPlusIcon } from './icons/UserPlusIcon';
import { UsersIcon } from './icons/UsersIcon';

interface NotificationToastProps {
  notification: Notification;
  onClose: () => void;
}

const getIconForType = (type: Notification['type']) => {
    switch(type) {
        case 'new_challenge': return <FlagIcon className="w-6 h-6 text-cyan-300" />;
        case 'new_follower': return <UserPlusIcon className="w-6 h-6 text-green-300" />;
        case 'team_invite': return <UsersIcon className="w-6 h-6 text-teal-300" />;
        default: return null;
    }
}

export const NotificationToast: React.FC<NotificationToastProps> = ({ notification, onClose }) => {
  return (
    <div className="w-full max-w-sm bg-gray-800/80 backdrop-blur-sm rounded-lg shadow-lg border border-gray-700 overflow-hidden animate-fade-in-right">
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            {getIconForType(notification.type)}
          </div>
          <div className="ml-3 w-0 flex-1">
            <p className="text-sm font-medium text-white">
              {notification.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </p>
            <p className="mt-1 text-sm text-gray-300">
              {notification.message}
            </p>
          </div>
          <div className="ml-4 flex-shrink-0 flex">
            <button
              onClick={onClose}
              className="inline-flex text-gray-400 hover:text-white"
              aria-label="Close notification"
            >
              <span className="sr-only">Close</span>
              <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
