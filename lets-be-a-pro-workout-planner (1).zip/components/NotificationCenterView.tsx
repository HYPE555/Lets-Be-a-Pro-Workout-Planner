import React, { useState } from 'react';
import { Notification, UserProfile } from '../types';
import { FlagIcon } from './icons/FlagIcon';
import { UserPlusIcon } from './icons/UserPlusIcon';
import { UsersIcon } from './icons/UsersIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { NotificationBellIcon } from './icons/NotificationBellIcon';

interface NotificationCenterViewProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  users: UserProfile[];
}

const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.round((now.getTime() - date.getTime()) / 1000);
    const minutes = Math.round(seconds / 60);
    const hours = Math.round(minutes / 60);
    const days = Math.round(hours / 24);

    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
};

const getIconForType = (type: Notification['type'], isRead: boolean) => {
    const className = `w-6 h-6 ${isRead ? 'text-gray-500' : 'text-cyan-400'}`;
    switch(type) {
        case 'new_challenge': return <FlagIcon className={className} />;
        case 'new_follower': return <UserPlusIcon className={className} />;
        case 'team_invite': return <UsersIcon className={className} />;
        default: return null;
    }
}

export const NotificationCenterView: React.FC<NotificationCenterViewProps> = ({ notifications, onMarkAsRead, onMarkAllAsRead, users }) => {
  const [filter, setFilter] = useState<'all' | Notification['type']>('all');

  const filteredNotifications = notifications
    .filter(n => filter === 'all' || n.type === filter)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const hasUnread = notifications.some(n => !n.isRead);

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Notifications</h1>
        {hasUnread && (
            <button onClick={onMarkAllAsRead} className="flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 font-semibold transition-colors">
                <CheckCircleIcon className="w-5 h-5" />
                Mark all as read
            </button>
        )}
      </header>
      
      <div className="flex flex-wrap gap-2 p-2 bg-gray-800/50 rounded-lg border border-gray-700">
        {(['all', 'new_follower', 'new_challenge', 'team_invite'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${filter === f ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>
                {f.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map(notification => (
            <div
              key={notification.id}
              onClick={() => !notification.isRead && onMarkAsRead(notification.id)}
              className={`relative bg-gray-800 rounded-lg p-4 border transition-colors ${!notification.isRead ? 'border-cyan-700/50 hover:bg-gray-700/50 cursor-pointer' : 'border-gray-700/50'}`}
              role="button"
              aria-label={`Notification: ${notification.message}. Click to mark as read.`}
            >
              {!notification.isRead && (
                <span className="absolute top-3 right-3 h-2.5 w-2.5 rounded-full bg-cyan-400" title="Unread"></span>
              )}
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 pt-1">
                  {getIconForType(notification.type, notification.isRead)}
                </div>
                <div>
                  <p className={`text-sm ${notification.isRead ? 'text-gray-400' : 'text-gray-200'}`}>{notification.message}</p>
                  <p className={`text-xs mt-1 ${notification.isRead ? 'text-gray-500' : 'text-gray-400'}`}>
                    {timeAgo(notification.timestamp)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center text-gray-500 bg-gray-800/50 rounded-2xl p-8 border border-gray-700">
            <NotificationBellIcon className="w-12 h-12 mx-auto text-gray-600 mb-4" unreadCount={0} />
            <h2 className="text-xl font-bold text-white mb-2">All caught up!</h2>
            <p>You have no notifications in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
};