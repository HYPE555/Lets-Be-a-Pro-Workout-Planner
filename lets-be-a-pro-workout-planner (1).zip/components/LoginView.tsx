
import React from 'react';
import { UserProfile } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { UserIcon } from './icons/UserIcon';

interface LoginViewProps {
  users: UserProfile[];
  onLogin: (user: UserProfile) => void;
  onGoToSignUp: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ users, onLogin, onGoToSignUp }) => {

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 text-gray-100 p-4">
      <div className="max-w-md w-full text-center bg-gray-800/50 rounded-2xl shadow-lg p-8 backdrop-blur-sm border border-gray-700 animate-fade-in">
        <div className="flex items-center justify-center gap-4 mb-4">
          <SparklesIcon className="w-10 h-10 text-cyan-400" />
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">
            AI Workout Planner
          </h1>
        </div>
        <p className="mt-2 mb-8 text-lg text-gray-400">
          Sign in to continue or create a new account.
        </p>
        
        <div className="space-y-3">
          <h2 className="text-xl font-semibold text-white">Select a Profile</h2>
          {users.length > 0 ? (
            users.map(user => (
              <button
                key={user.userId}
                onClick={() => onLogin(user)}
                className="w-full flex items-center gap-4 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-left"
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-800">
                  <UserIcon className="w-6 h-6 text-gray-400" />
                </div>
                <div>
                  <p className="font-bold text-white">{user.name}</p>
                  <p className="text-sm text-gray-400 capitalize">{user.role.replace('_', ' ')}</p>
                </div>
              </button>
            ))
          ) : (
            <p className="text-gray-500">No profiles found. Please create an account.</p>
          )}
        </div>

        <div className="mt-6 flex items-center">
          <div className="flex-grow border-t border-gray-600"></div>
          <span className="flex-shrink mx-4 text-gray-400 text-sm">OR</span>
          <div className="flex-grow border-t border-gray-600"></div>
        </div>

        <div className="mt-6">
            <button
                onClick={onGoToSignUp}
                className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg"
            >
                Create New Account
            </button>
        </div>

        <p className="text-xs text-gray-600 mt-8">
            This is a simulated login. Your data is stored only in your browser.
        </p>
      </div>
    </div>
  );
};
