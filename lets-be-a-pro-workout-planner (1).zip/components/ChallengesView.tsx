import React from 'react';
import { Challenge, UserProfile } from '../types';
import { FlagIcon } from './icons/FlagIcon';
import { UserIcon } from './icons/UserIcon';
import { CalendarIcon } from './icons/CalendarIcon';

interface ChallengesViewProps {
  allChallenges: Challenge[];
  profile: UserProfile;
  users: UserProfile[];
}

export const ChallengesView: React.FC<ChallengesViewProps> = ({ allChallenges, profile, users }) => {
  const teamId = profile.teamId;

  if (!teamId) {
    return (
      <div className="text-center text-gray-500 bg-gray-800/50 rounded-2xl p-8 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-2">No Team Found</h2>
        <p>You need to be on a team to view challenges. Go to the 'Teams' tab to join one.</p>
      </div>
    );
  }
  
  const teamChallenges = allChallenges.filter(c => c.teamId === teamId);
  
  const getCoachName = (coachId: string): string => {
    const coach = users.find(u => u.userId === coachId && u.role === 'coach');
    return coach ? coach.name : 'Unknown Coach';
  };
  
  const getChallengeStatus = (challenge: Challenge): { text: string; color: string } => {
    const now = new Date();
    const startDate = challenge.startDate ? new Date(challenge.startDate) : null;
    const endDate = challenge.endDate ? new Date(challenge.endDate) : null;

    if (endDate) {
        endDate.setHours(23, 59, 59, 999); // Make end date inclusive
    }

    if (startDate && now < startDate) {
        return { text: 'Upcoming', color: 'bg-yellow-500/20 text-yellow-300' };
    }
    if (endDate && now > endDate) {
        return { text: 'Ended', color: 'bg-red-500/20 text-red-400' };
    }
    if (startDate && (!endDate || now <= endDate)) {
        return { text: 'Active', color: 'bg-green-500/20 text-green-300' };
    }
    return { text: 'Ongoing', color: 'bg-gray-500/20 text-gray-300' }; // No dates set
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <header className="text-center">
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">
          Team Challenges
        </h1>
        <p className="mt-2 text-lg text-gray-400">
          Your coach has issued the following challenges. Good luck!
        </p>
      </header>

      {teamChallenges.length > 0 ? (
        <div className="space-y-4">
          {teamChallenges.map(challenge => {
            const status = getChallengeStatus(challenge);
            return (
                <div key={challenge.id} className="bg-gray-800 rounded-2xl border border-gray-700 p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-cyan-900/50 rounded-full border border-cyan-700">
                        <FlagIcon className="w-6 h-6 text-cyan-400" />
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between items-center">
                        <h2 className="text-xl font-bold text-white">{challenge.title}</h2>
                        <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${status.color}`}>{status.text}</span>
                      </div>
                      <p className="text-sm text-gray-400 mt-2">{challenge.description}</p>
                      <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-700">
                        <UserIcon className="w-4 h-4 text-gray-500" />
                        <span className="text-xs text-gray-400">
                          Assigned by <span className="font-semibold text-gray-300">{getCoachName(challenge.coachId)}</span> on {new Date(challenge.createdAt).toLocaleDateString()}
                        </span>
                        {(challenge.startDate || challenge.endDate) && (
                            <>
                            <span className="text-gray-600">|</span>
                            <CalendarIcon className="w-4 h-4 text-gray-500" />
                            <span className="text-xs text-gray-400">
                                {challenge.startDate ? new Date(challenge.startDate).toLocaleDateString() : '...'} - {challenge.endDate ? new Date(challenge.endDate).toLocaleDateString() : '...'}
                            </span>
                            </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
            )
          })}
        </div>
      ) : (
        <div className="text-center text-gray-500 bg-gray-800/50 rounded-2xl p-8 border border-gray-700">
            <FlagIcon className="w-12 h-12 mx-auto text-gray-600 mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">No Challenges Yet</h2>
            <p>Your coach hasn't assigned any challenges to your team. Check back later!</p>
        </div>
      )}
    </div>
  );
};