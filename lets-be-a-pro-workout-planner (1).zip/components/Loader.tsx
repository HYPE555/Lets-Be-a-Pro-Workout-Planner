
import React from 'react';
import { DumbbellIcon } from './icons/DumbbellIcon';

interface LoaderProps {
  message?: string;
  subtext?: string;
}

export const Loader: React.FC<LoaderProps> = ({ message = "Generating your plan...", subtext = "The AI is warming up!" }) => {
  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <DumbbellIcon className="w-12 h-12 text-cyan-400 animate-bounce" />
      <p className="text-lg font-semibold text-gray-300">{message}</p>
      <p className="text-sm text-gray-500">{subtext}</p>
    </div>
  );
};
