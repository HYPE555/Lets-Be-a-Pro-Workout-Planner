export type FitnessLevel = 'beginner' | 'intermediate' | 'advanced';
export type Day = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export interface WorkoutPreferences {
  goals: string[];
  fitnessLevel: FitnessLevel;
  availableDays: Day[];
  duration: string;
  equipment: string[];
  notes: string;
  customExercises?: { name: string }[];
}

export interface ExerciseVariation {
  name: string;
  description: string;
}

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  rest: string;
  description: string;
  variations?: ExerciseVariation[];
}

export interface DailyWorkout {
  day: Day;
  focus: string;
  warmup: string;
  exercises: Exercise[];
  cooldown: string;
}

export interface WorkoutPlan {
  weeklyPlan: DailyWorkout[];
}

export interface Team {
  id: string;
  name: string;
  joinCode: string;
}

export type UserRole = 'player' | 'coach' | 'team_organizer';

export interface UserProfile {
  userId: string;
  name: string;
  email: string;
  role: UserRole;
  age: number | '';
  weight: number | '';
  height: number | '';
  teamId?: string;
}

export interface Invitation {
  teamId: string;
  email: string;
  invitedAt: string; // ISO string date
}

export interface WorkoutLog {
  id: string;
  date: string;
  plan: WorkoutPlan;
  preferences: WorkoutPreferences;
}

export interface ExerciseLog {
  date: string; // ISO string date
  exerciseName: string;
  weight: number;
  reps: number;
}

export interface UserSpecificData {
  history: WorkoutLog[];
  progressData: ExerciseLog[];
  preferences: WorkoutPreferences;
  workoutPlan: WorkoutPlan | null;
}

export interface Challenge {
  id: string;
  teamId: string;
  title: string;
  description: string;
  coachId: string;
  createdAt: string; // ISO string date
  startDate?: string; // ISO string date
  endDate?: string; // ISO string date
}

export interface PlayerStatSummary {
  totalWorkouts: number;
  personalBests: Record<string, { weight: number; reps: number }>;
}

export interface Follow {
  followerId: string;
  followingId: string;
}

export interface ActivityLog {
  userId: string;
  userName: string;
  type: 'workout_plan' | 'exercise_log';
  timestamp: string; // ISO String
  details: string;
}

export interface TeamMessage {
  id: string;
  teamId: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: string; // ISO string date
}

export interface Notification {
  id: string;
  userId: string; // The user who receives the notification
  type: 'new_challenge' | 'new_follower' | 'team_invite';
  message: string;
  timestamp: string; // ISO string date
  isRead: boolean;
  relatedId?: string; // e.g., userId of follower, challengeId, teamId
}