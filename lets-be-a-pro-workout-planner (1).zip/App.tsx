
import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { WorkoutPreferences, WorkoutPlan, UserProfile, WorkoutLog, ExerciseLog, Team, Invitation, UserSpecificData, Challenge, Follow, ActivityLog, TeamMessage, Notification } from './types';
import { WorkoutForm } from './components/WorkoutForm';
import { TimetableDisplay } from './components/TimetableDisplay';
import { generateWorkoutPlan } from './services/geminiService';
import { Loader } from './components/Loader';
import { ProfileView } from './components/ProfileView';
import { StatsView } from './components/StatsView';
import { SparklesIcon } from './components/icons/SparklesIcon';
import { UserIcon } from './components/icons/UserIcon';
import { ChartBarIcon } from './components/icons/ChartBarIcon';
import { DumbbellIcon } from './components/icons/DumbbellIcon';
import { HockeyIcon } from './components/icons/HockeyIcon';
import { PlanFilters } from './components/PlanFilters';
import { Toast } from './components/Toast';
import { ProfileSetupView } from './components/ProfileSetupView';
import { TeamView } from './components/TeamView';
import { UsersIcon } from './components/icons/UsersIcon';
import { LoginView } from './components/LoginView';
import { ChallengesView } from './components/ChallengesView';
import { FlagIcon } from './components/icons/FlagIcon';
import { PublicProfileView } from './components/PublicProfileView';
import { FollowsModal } from './components/FollowsModal';
import { TeamPageView } from './components/TeamPageView';
import { AboutView } from './components/AboutView';
import { InfoIcon } from './components/icons/InfoIcon';
import { NotificationBellIcon } from './components/icons/NotificationBellIcon';
import { NotificationCenterView } from './components/NotificationCenterView';
import { NotificationToast } from './components/NotificationToast';

type View = 'planner' | 'profile' | 'history' | 'teams' | 'challenges' | 'about' | 'notifications';
export type AppMode = 'general' | 'hockey';

const MOCK_USERS: UserProfile[] = [
    { userId: 'player-1', name: 'Alex Johnson', email: 'alex@example.com', role: 'player', age: 24, weight: 88, height: 185, teamId: 'team-1' },
    { userId: 'player-2', name: 'Brianna Williams', email: 'brianna@example.com', role: 'player', age: 22, weight: 85, height: 180, teamId: 'team-1' },
    { userId: 'coach-1', name: 'Coach Casey Smith', email: 'casey@example.com', role: 'coach', age: 35, weight: 92, height: 190 },
    { userId: 'organizer-1', name: 'Pat Manager', email: 'pat@example.com', role: 'team_organizer', age: 42, weight: 80, height: 175 },
];

const MOCK_TEAMS: Team[] = [
    { id: 'team-1', name: 'Dragons', joinCode: 'DRGN-1234' },
    { id: 'team-2', name: 'Wolverines', joinCode: 'WLVN-5678' },
];

const initialPreferences: WorkoutPreferences = {
    goals: [],
    fitnessLevel: 'beginner',
    availableDays: [],
    duration: '45',
    equipment: [],
    notes: '',
    customExercises: [],
};


// FIX: Export 'App' component to resolve import error in index.tsx.
// FIX: Completed the component implementation with state management, handlers, and JSX return to resolve the "no return" error.
export const App: React.FC = () => {
  const [preferences, setPreferences] = useState<WorkoutPreferences>(initialPreferences);
  const [workoutPlan, setWorkoutPlan] = useState<WorkoutPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<View>('planner');
  const [appMode, setAppMode] = useState<AppMode>('general');
  const hasGeneratedOnce = useRef(false);
  const isInitialMount = useRef(true);
  
  const [currentView, setCurrentView] = useState<'login' | 'signup' | 'app' | null>(null);

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [history, setHistory] = useState<WorkoutLog[]>([]);
  const [progressData, setProgressData] = useState<ExerciseLog[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [follows, setFollows] = useState<Follow[]>([]);
  const [messages, setMessages] = useState<TeamMessage[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [notificationToasts, setNotificationToasts] = useState<Notification[]>([]);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  
  const [viewingPlayer, setViewingPlayer] = useState<UserProfile | null>(null);
  const [viewedPlayerData, setViewedPlayerData] = useState<{ history: WorkoutLog[], progressData: ExerciseLog[] } | null>(null);

  const [viewingPublicProfile, setViewingPublicProfile] = useState<UserProfile | null>(null);
  const [followsModalData, setFollowsModalData] = useState<{ user: UserProfile; type: 'followers' | 'following' } | null>(null);
  const [viewingTeam, setViewingTeam] = useState<Team | null>(null);
  
  const [allUsersData, setAllUsersData] = useState<Record<string, UserSpecificData>>({});

  const showNotificationToast = (notification: Notification) => {
    setNotificationToasts(prev => [...prev, notification]);
    setTimeout(() => {
        handleDismissToast(notification.id);
    }, 7000); // Auto-dismiss after 7 seconds
  };
  
  const addNotifications = (newNotifications: Notification[]) => {
      setNotifications(prev => [...prev, ...newNotifications]);
      // If any of the new notifications are for the currently logged-in user, show a toast
      if (profile) {
          const currentUserNotifications = newNotifications.filter(n => n.userId === profile.userId);
          currentUserNotifications.forEach(showNotificationToast);
      }
  };

  // Load global data (non-user-specific) from localStorage on mount and check for a saved user session
  useEffect(() => {
    try {
        // Load and set global data first
        const savedUsersJSON = localStorage.getItem('allUsers');
        const savedTeamsJSON = localStorage.getItem('hockeyTeams');
        const savedInvitationsJSON = localStorage.getItem('playerInvitations');
        const savedChallengesJSON = localStorage.getItem('teamChallenges');
        const savedFollowsJSON = localStorage.getItem('userFollows');
        const savedMessagesJSON = localStorage.getItem('teamMessages');
        const savedNotificationsJSON = localStorage.getItem('userNotifications');

        let allUsers: UserProfile[];
        if (!savedUsersJSON || JSON.parse(savedUsersJSON).length === 0) {
            allUsers = MOCK_USERS;
            setUsers(MOCK_USERS);
            localStorage.setItem('allUsers', JSON.stringify(MOCK_USERS));
        } else {
            allUsers = JSON.parse(savedUsersJSON);
            setUsers(allUsers);
        }
        
        if (!savedTeamsJSON) {
            setTeams(MOCK_TEAMS);
            localStorage.setItem('hockeyTeams', JSON.stringify(MOCK_TEAMS));
        } else {
            setTeams(JSON.parse(savedTeamsJSON));
        }

        if (savedInvitationsJSON) setInvitations(JSON.parse(savedInvitationsJSON));
        if (savedChallengesJSON) setChallenges(JSON.parse(savedChallengesJSON));
        if (savedFollowsJSON) setFollows(JSON.parse(savedFollowsJSON));
        if (savedNotificationsJSON) setNotifications(JSON.parse(savedNotificationsJSON));
        // Load persisted team chat messages
        if (savedMessagesJSON) setMessages(JSON.parse(savedMessagesJSON));
        
        const savedMode = localStorage.getItem('appMode');
        if (savedMode === 'hockey' || savedMode === 'general') {
            setAppMode(savedMode as AppMode);
        }

        const loadedData: Record<string, UserSpecificData> = {};
        for (const user of allUsers) {
            const userDataJSON = localStorage.getItem(`userData_${user.userId}`);
            if (userDataJSON) {
                loadedData[user.userId] = JSON.parse(userDataJSON);
            }
        }
        setAllUsersData(loadedData);


        // Now, check for a logged-in user session
        const savedUserId = localStorage.getItem('currentUserId');
        if (savedUserId) {
            const userToLogin = allUsers.find(u => u.userId === savedUserId);
            if (userToLogin) {
                handleLogin(userToLogin); // This will set the view to 'app'
            } else {
                // User from session not found in user list, clear it and go to login
                localStorage.removeItem('currentUserId');
                setCurrentView('login');
            }
        } else {
            // No saved user, go to login
            setCurrentView('login');
        }

    } catch (e) {
        console.error("Failed to load global data from localStorage", e);
        setCurrentView('login'); // Fallback on any error
    }
    isInitialMount.current = false;
  }, []);

  // Save global data to localStorage when it changes
  useEffect(() => {
    if (!isInitialMount.current) {
        try {
            localStorage.setItem('allUsers', JSON.stringify(users));
            if (profile?.role === 'player') { // Only save app mode for players
                localStorage.setItem('appMode', appMode);
            }
            localStorage.setItem('hockeyTeams', JSON.stringify(teams));
            localStorage.setItem('playerInvitations', JSON.stringify(invitations));
            localStorage.setItem('teamChallenges', JSON.stringify(challenges));
            localStorage.setItem('userFollows', JSON.stringify(follows));
            localStorage.setItem('userNotifications', JSON.stringify(notifications));
            // Persist team chat messages
            localStorage.setItem('teamMessages', JSON.stringify(messages));
        } catch (e) {
            console.error("Failed to save global data to localStorage", e);
        }
    }
  }, [users, appMode, teams, invitations, challenges, follows, messages, notifications, profile]);

  // Save user-specific data whenever it changes for the logged-in user
  useEffect(() => {
    if (profile && !isInitialMount.current) {
        try {
            const userData: UserSpecificData = {
                history,
                progressData,
                preferences,
                workoutPlan
            };
            localStorage.setItem(`userData_${profile.userId}`, JSON.stringify(userData));
        } catch(e) {
            console.error("Failed to save user-specific data to localStorage", e);
            setToast({ message: "Could not save your progress.", type: 'error' });
        }
    }
  }, [history, progressData, preferences, workoutPlan, profile]);
  
    const updateProfileAndUsers = (newProfileData: UserProfile | ((prev: UserProfile) => UserProfile)) => {
        const updatedProfile = typeof newProfileData === 'function' 
            ? newProfileData(profile!) 
            : newProfileData;
    
        setProfile(updatedProfile);
    
        setUsers(prevUsers => {
            const userIndex = prevUsers.findIndex(u => u.userId === updatedProfile.userId);
            if (userIndex > -1) {
                const newUsers = [...prevUsers];
                newUsers[userIndex] = updatedProfile;
                return newUsers;
            }
            return [...prevUsers, updatedProfile]; 
        });
    };

  const handleModeToggle = () => {
    setAppMode(prevMode => {
        const newMode = prevMode === 'general' ? 'hockey' : 'general';
        if (newMode === 'general' && (activeView === 'teams' || activeView === 'challenges')) {
            if (profile?.role === 'player') {
                setActiveView('planner');
            } else {
                setActiveView('profile');
            }
        }
        setPreferences(p => ({ ...p, goals: [] }));
        setToast({ message: `Switched to ${newMode === 'hockey' ? 'Hockey' : 'General Fitness'} Mode`, type: 'success' });
        return newMode;
    });
  };

  const handleGeneratePlan = useCallback(async () => {
    if (!profile || profile.role !== 'player') {
        setError("Only players can generate workout plans.");
        return;
    }
    if (preferences.goals.length === 0 || preferences.availableDays.length === 0) {
      setError("Please select at least one goal and one available day.");
      setToast({ message: "Please select your goals and available days.", type: 'error' });
      return;
    }
    setIsLoading(true);
    setError(null);
    hasGeneratedOnce.current = true;
    try {
      const plan = await generateWorkoutPlan(preferences, appMode, profile, teams);
      setWorkoutPlan(plan);
      const newLog: WorkoutLog = {
        id: new Date().toISOString(),
        date: new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }),
        plan: plan,
        preferences: preferences,
      };
      setHistory(prev => [newLog, ...prev]);

      setAllUsersData(prev => ({
        ...prev,
        [profile.userId]: {
            ...prev[profile.userId],
            history: [newLog, ...(prev[profile.userId]?.history || [])],
            workoutPlan: plan,
            preferences: preferences,
        }
      }));

      setToast({ message: "Workout plan generated successfully!", type: 'success' });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred while generating the plan.";
      setError(errorMessage);
      setToast({ message: errorMessage, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  }, [preferences, appMode, profile, teams]);
  
  const handleProfileCreate = (createdProfile: UserProfile) => {
    const pendingInvite = invitations.find(inv => inv.email.toLowerCase() === createdProfile.email.toLowerCase());
    if (pendingInvite) {
        createdProfile.teamId = pendingInvite.teamId;
        const team = teams.find(t => t.id === pendingInvite.teamId);
        setInvitations(prev => prev.filter(inv => inv.email.toLowerCase() !== createdProfile.email.toLowerCase()));
        setToast({ message: `Welcome! You've been added to team ${team?.name}.`, type: 'success' });

        const newNotification: Notification = {
            id: crypto.randomUUID(),
            userId: createdProfile.userId,
            type: 'team_invite',
            message: `You've successfully joined ${team?.name || 'your new team'}. Welcome!`,
            timestamp: new Date().toISOString(),
            isRead: false,
            relatedId: pendingInvite.teamId,
        };
        setNotifications(prev => [...prev, newNotification]);
        showNotificationToast(newNotification); // Show toast for the new user
    }

    updateProfileAndUsers(createdProfile);
    
    setHistory([]);
    setProgressData([]);
    setWorkoutPlan(null);
    setPreferences(initialPreferences);

    localStorage.setItem('currentUserId', createdProfile.userId);
    setProfile(createdProfile);
    setCurrentView('app');

    if (createdProfile.role === 'player') {
        setAppMode('general');
        setActiveView('planner');
    } else { 
        setAppMode('hockey');
        setActiveView('teams');
    }
  };

  const handleSendInvite = (teamId: string, email: string) => {
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        setToast({ message: "A user with this email already exists.", type: 'error' });
        return;
    }
    if (invitations.some(inv => inv.email.toLowerCase() === email.toLowerCase())) {
        setToast({ message: "An invitation has already been sent to this email.", type: 'error' });
        return;
    }
    const newInvitation: Invitation = {
      teamId,
      email: email.toLowerCase(),
      invitedAt: new Date().toISOString(),
    };
    setInvitations(prev => [...prev, newInvitation]);
    setToast({ message: `Invitation sent to ${email}!`, type: 'success' });
  };
  
  const handleCreateChallenge = (teamId: string, title: string, description: string, startDate?: string, endDate?: string) => {
    if (!profile || (profile.role !== 'coach' && profile.role !== 'team_organizer')) return;

    const newChallenge: Challenge = {
      id: crypto.randomUUID(),
      teamId,
      title,
      description,
      coachId: profile.userId,
      createdAt: new Date().toISOString(),
      startDate,
      endDate,
    };
    setChallenges(prev => [...prev, newChallenge]);
    setToast({ message: `Challenge "${title}" has been sent to the team!`, type: 'success' });
    
    const teamPlayers = users.filter(u => u.teamId === teamId && u.role === 'player');
    const newNotifications: Notification[] = teamPlayers.map(player => ({
        id: crypto.randomUUID(),
        userId: player.userId,
        type: 'new_challenge',
        message: `Your coach ${profile.name} issued a new challenge: "${title}"`,
        timestamp: new Date().toISOString(),
        isRead: false,
        relatedId: newChallenge.id,
    }));
    addNotifications(newNotifications);
  };
  
  const handleLogExercise = (log: Omit<ExerciseLog, 'date'>) => {
    if (!profile) return;
    const newLog: ExerciseLog = {
      ...log,
      date: new Date().toISOString(),
    };
    setProgressData(prev => [...prev, newLog]);
    setAllUsersData(prev => ({
        ...prev,
        [profile.userId]: {
            ...prev[profile.userId],
            progressData: [...(prev[profile.userId]?.progressData || []), newLog]
        }
    }));
    setToast({ message: `${log.exerciseName} logged!`, type: 'success' });
  };
  
  const handleLogin = (userProfile: UserProfile) => {
    localStorage.setItem('currentUserId', userProfile.userId);
    
    try {
        const savedData = localStorage.getItem(`userData_${userProfile.userId}`);
        if (savedData) {
            const userData: UserSpecificData = JSON.parse(savedData);
            setHistory(userData.history || []);
            setProgressData(userData.progressData || []);
            setPreferences(userData.preferences || initialPreferences);
            setWorkoutPlan(userData.workoutPlan || null);
        } else {
            setHistory([]);
            setProgressData([]);
            setPreferences(initialPreferences);
            setWorkoutPlan(null);
        }
    } catch(e) {
        console.error("Failed to load or parse user data from localStorage", e);
        setToast({ message: "Could not load your profile data.", type: 'error' });
        setHistory([]);
        setProgressData([]);
        setPreferences(initialPreferences);
        setWorkoutPlan(null);
    }
      
    setProfile(userProfile);
    setCurrentView('app');
    
    if (userProfile.role === 'player') {
        const savedMode = localStorage.getItem('appMode');
        if (savedMode === 'hockey' || savedMode === 'general') {
            setAppMode(savedMode as AppMode);
        } else {
            setAppMode('general');
        }
        setActiveView('planner');
    } else { 
        setAppMode('hockey');
        setActiveView('teams');
    }
  };

  const handleLogout = () => {
      localStorage.removeItem('currentUserId');
      setProfile(null);
      setCurrentView('login');
      
      setHistory([]);
      setProgressData([]);
      setWorkoutPlan(null);
      setPreferences(initialPreferences);
      setError(null);
      
      setToast({ message: "You have been logged out.", type: 'success' });
  };
  
  const handleViewPlayerStats = (player: UserProfile) => {
    try {
        const savedData = localStorage.getItem(`userData_${player.userId}`);
        if (savedData) {
            const userData: UserSpecificData = JSON.parse(savedData);
            setViewedPlayerData({
                history: userData.history || [],
                progressData: userData.progressData || []
            });
        } else {
            setViewedPlayerData({ history: [], progressData: [] }); 
        }
        setViewingPlayer(player);
    } catch(e) {
        console.error("Failed to load player data", e);
        setToast({ message: `Could not load data for ${player.name}.`, type: 'error' });
    }
  };

  const handleExitPlayerStatsView = () => {
      setViewingPlayer(null);
      setViewedPlayerData(null);
  };
  
  const handleFollow = (userIdToFollow: string) => {
    if (!profile) return;
    setFollows(prev => [...prev, { followerId: profile.userId, followingId: userIdToFollow }]);
    setToast({ message: `You are now following ${users.find(u => u.userId === userIdToFollow)?.name}.`, type: 'success' });

    const newNotification: Notification = {
        id: crypto.randomUUID(),
        userId: userIdToFollow,
        type: 'new_follower',
        message: `${profile.name} started following you.`,
        timestamp: new Date().toISOString(),
        isRead: false,
        relatedId: profile.userId,
    };
    addNotifications([newNotification]);
  };

  const handleUnfollow = (userIdToUnfollow: string) => {
    if (!profile) return;
    setFollows(prev => prev.filter(f => !(f.followerId === profile.userId && f.followingId === userIdToUnfollow)));
    setToast({ message: `You have unfollowed ${users.find(u => u.userId === userIdToUnfollow)?.name}.`, type: 'success' });
  };

  const handleViewPublicProfile = (user: UserProfile) => {
    setViewingPublicProfile(user);
  };
  
  const handleClosePublicProfile = () => {
    setViewingPublicProfile(null);
  };

  const handleOpenFollowsModal = (user: UserProfile, type: 'followers' | 'following') => {
    setFollowsModalData({ user, type });
  };

  const handleCloseFollowsModal = () => {
    setFollowsModalData(null);
  };

  const handleViewTeamPage = (team: Team) => {
    setViewingTeam(team);
  };

  const handleBackToTeams = () => {
    setViewingTeam(null);
  };

  const handleSendMessage = (teamId: string, messageText: string) => {
    if (!profile || !messageText.trim()) return;
    const newMessage: TeamMessage = {
      id: crypto.randomUUID(),
      teamId,
      userId: profile.userId,
      userName: profile.name,
      message: messageText.trim(),
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, newMessage]);
  };
  
  const handleMarkNotificationAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
  };

  const handleMarkAllAsRead = () => {
      if (!profile) return;
      setNotifications(prev => prev.map(n => n.userId === profile.userId ? { ...n, isRead: true } : n));
  };
  
  const handleDismissToast = (notificationId: string) => {
      setNotificationToasts(prev => prev.filter(n => n.id !== notificationId));
  };

  const activityFeed = useMemo(() => {
    const activities: ActivityLog[] = [];
    for (const userId in allUsersData) {
        const userData = allUsersData[userId];
        const user = users.find(u => u.userId === userId);
        if (!user) continue;

        // Map workout history
        (userData.history || []).forEach(log => {
            activities.push({
                userId: user.userId,
                userName: user.name,
                type: 'workout_plan',
                timestamp: log.id, // ISO string date
                details: `generated a new plan focused on ${log.preferences.goals.join(', ') || 'their goals'}.`
            });
        });

        // Map exercise logs
        (userData.progressData || []).forEach(log => {
            activities.push({
                userId: user.userId,
                userName: user.name,
                type: 'exercise_log',
                timestamp: log.date, // ISO string date
                details: `logged ${log.exerciseName}: ${log.weight}kg for ${log.reps} reps.`
            });
        });
    }
    // Sort by date, newest first
    return activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [allUsersData, users]);

  const unreadCount = useMemo(() => {
    if (!profile) return 0;
    return notifications.filter(n => n.userId === profile.userId && !n.isRead).length;
  }, [notifications, profile]);

  const NavButton: React.FC<{ view: View; label: string; icon: React.ReactNode; }> = ({ view, label, icon }) => (
    <button
      onClick={() => setActiveView(view)}
      className={`flex flex-col items-center justify-center space-y-1 w-20 h-16 rounded-lg transition-all duration-200 ${
        activeView === view ? 'bg-cyan-500 text-white shadow-lg' : 'text-gray-400 hover:bg-gray-700 hover:text-white'
      }`}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
  
  if (currentView === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <Loader message="Loading Profile..." subtext="Getting things ready for you." />
      </div>
    );
  }
  
  if (currentView === 'login') {
      return <LoginView users={users} onLogin={handleLogin} onGoToSignUp={() => setCurrentView('signup')} />;
  }
  
  if (currentView === 'signup' || !profile) {
      return <ProfileSetupView onProfileCreate={handleProfileCreate} onBackToLogin={() => setCurrentView('login')} invitations={invitations} />;
  }
  
  if (viewingPlayer && viewedPlayerData) {
    return (
        <div className="bg-gray-900 text-white min-h-screen font-sans flex flex-col">
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
            <header className="w-full max-w-5xl mx-auto px-4 pt-6">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-2xl font-bold">Player Stats</h1>
                        <p className="text-cyan-400">Viewing profile for: {viewingPlayer.name}</p>
                    </div>
                    <button
                        onClick={handleExitPlayerStatsView}
                        className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                    >
                        &larr; Back to Teams
                    </button>
                </div>
            </header>
            <main className="flex-grow w-full max-w-5xl mx-auto p-4">
                <StatsView 
                    history={viewedPlayerData.history} 
                    progressData={viewedPlayerData.progressData} 
                    isCoachView={true}
                />
            </main>
        </div>
    );
  }

  const ModeIcon = appMode === 'general' ? DumbbellIcon : HockeyIcon;
  const appTitle = appMode === 'general' ? "AI Workout Planner" : "AI Hockey Trainer";


  return (
    <div className="bg-gray-900 text-white min-h-screen font-sans flex flex-col">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <div className="fixed top-5 right-5 z-50 w-full max-w-sm space-y-3">
        {notificationToasts.map(n => (
            <NotificationToast key={n.id} notification={n} onClose={() => handleDismissToast(n.id)} />
        ))}
      </div>

      <header className="w-full max-w-5xl mx-auto px-4 pt-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <ModeIcon className="w-8 h-8 text-cyan-400" />
            <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-cyan-400 to-teal-400 text-transparent bg-clip-text">
              {appTitle} <span className="text-sm font-medium text-gray-400 capitalize">({profile.role.replace('_', ' ')})</span>
            </h1>
          </div>
          {profile.role === 'player' && (
            <button
                onClick={handleModeToggle}
                className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-sm font-medium text-gray-300 py-2 px-4 rounded-lg transition-colors duration-200"
                aria-label={`Switch to ${appMode === 'general' ? 'Hockey' : 'General Fitness'} mode`}
            >
                {appMode === 'general' ? <HockeyIcon className="w-5 h-5"/> : <DumbbellIcon className="w-5 h-5"/>}
                <span>{appMode === 'general' ? 'Hockey Mode' : 'Fitness Mode'}</span>
            </button>
          )}
        </div>
      </header>

      <main className="flex-grow w-full max-w-5xl mx-auto p-4">
        {activeView === 'planner' && (
          profile.role === 'player' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
              <div className="lg:col-span-1">
                <WorkoutForm 
                  preferences={preferences}
                  setPreferences={setPreferences}
                  onSubmit={handleGeneratePlan}
                  isLoading={isLoading}
                  appMode={appMode}
                />
              </div>
              <div className="lg:col-span-2">
                {isLoading ? (
                  <div className="flex justify-center items-center h-96">
                     <Loader subtext="Crafting your personalized regimen..." />
                  </div>
                ) : error && hasGeneratedOnce.current ? (
                  <div className="flex flex-col items-center justify-center h-96 bg-gray-800/50 rounded-2xl p-6 text-center border border-red-500/30">
                    <h3 className="text-xl font-semibold text-red-400">Generation Failed</h3>
                    <p className="text-gray-400 mt-2">{error}</p>
                    <button onClick={handleGeneratePlan} className="mt-6 bg-cyan-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-600">
                      Try Again
                    </button>
                  </div>
                ) : workoutPlan ? (
                  <>
                    <PlanFilters preferences={preferences} setPreferences={setPreferences} />
                    <TimetableDisplay plan={workoutPlan} onLogExercise={handleLogExercise} />
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-96 bg-gray-800/50 rounded-2xl p-6 text-center border border-gray-700">
                    <SparklesIcon className="w-12 h-12 text-gray-500 mb-4"/>
                    <h3 className="text-xl font-semibold text-white">Welcome, {profile.name}!</h3>
                    <p className="text-gray-400 mt-2 max-w-sm">Fill out your fitness profile on the left to generate a personalized workout plan designed just for you.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-96 bg-gray-800/50 rounded-2xl p-6 text-center border border-gray-700">
              <DumbbellIcon className="w-12 h-12 text-gray-500 mb-4"/>
              <h3 className="text-xl font-semibold text-white">Workout Planner is for Players</h3>
              <p className="text-gray-400 mt-2 max-w-sm">
                As a {profile.role.replace('_', ' ')}, your main functionalities are in the 'Teams' section and your 'Profile'.
              </p>
            </div>
          )
        )}

        {activeView === 'profile' && (
            <ProfileView 
                profile={profile} 
                setProfile={updateProfileAndUsers} 
                appMode={appMode} 
                teams={teams} 
                onLogout={handleLogout} 
                follows={follows} 
                onOpenFollowsModal={handleOpenFollowsModal} 
                setToast={setToast}
                activityFeed={activityFeed}
                users={users}
                onViewPublicProfile={handleViewPublicProfile}
            />
        )}
        
        {activeView === 'history' && profile.role === 'player' && <StatsView history={history} progressData={progressData} onLogExercise={handleLogExercise} />}
        
        {activeView === 'teams' && appMode === 'hockey' && (
          !viewingTeam ? (
            <TeamView 
              teams={teams}
              setTeams={setTeams}
              profile={profile}
              setProfile={updateProfileAndUsers}
              users={users}
              setToast={setToast}
              onViewTeamPage={handleViewTeamPage}
            />
          ) : (
            <TeamPageView
              team={viewingTeam}
              profile={profile}
              users={users}
              invitations={invitations}
              setProfile={updateProfileAndUsers}
              onSendInvite={handleSendInvite}
              setToast={setToast}
              onCreateChallenge={handleCreateChallenge}
              onViewPlayerStats={handleViewPlayerStats}
              onViewPublicProfile={handleViewPublicProfile}
              messages={messages}
              onSendMessage={handleSendMessage}
              onBack={handleBackToTeams}
              activityFeed={activityFeed}
            />
          )
        )}

        {activeView === 'challenges' && appMode === 'hockey' && profile.role === 'player' && <ChallengesView allChallenges={challenges} profile={profile} users={users} />}

        {activeView === 'about' && <AboutView />}

        {activeView === 'notifications' && (
            <NotificationCenterView 
                notifications={notifications.filter(n => n.userId === profile.userId)}
                onMarkAsRead={handleMarkNotificationAsRead}
                onMarkAllAsRead={handleMarkAllAsRead}
                users={users}
            />
        )}
      </main>

      {/* Bottom Navigation */}
      <footer className="sticky bottom-0 w-full bg-gray-800/80 backdrop-blur-sm border-t border-gray-700">
          <div className="max-w-md mx-auto p-2 flex justify-around">
            {profile.role === 'player' && <NavButton view="planner" label="Planner" icon={<DumbbellIcon className="w-6 h-6" />} />}
            {appMode === 'hockey' && (profile.role !== 'player' || profile.teamId) && <NavButton view="teams" label="Teams" icon={<UsersIcon className="w-6 h-6" />} />}
            {appMode === 'hockey' && profile.role === 'player' && profile.teamId && <NavButton view="challenges" label="Challenges" icon={<FlagIcon className="w-6 h-6" />} />}
            <NavButton view="profile" label="Profile" icon={<UserIcon className="w-6 h-6" />} />
            <NavButton view="notifications" label="Alerts" icon={<NotificationBellIcon className="w-6 h-6" unreadCount={unreadCount} />} />
            {profile.role === 'player' && <NavButton view="history" label="History" icon={<ChartBarIcon className="w-6 h-6" />} />}
            <NavButton view="about" label="About" icon={<InfoIcon className="w-6 h-6" />} />
          </div>
      </footer>

      {viewingPublicProfile && (
          <PublicProfileView 
            user={viewingPublicProfile}
            currentUser={profile}
            users={users}
            teams={teams}
            follows={follows}
            onClose={handleClosePublicProfile}
            onFollow={handleFollow}
            onUnfollow={handleUnfollow}
            onOpenFollowsModal={handleOpenFollowsModal}
          />
      )}

      {followsModalData && (
          <FollowsModal
            modalData={followsModalData}
            currentUser={profile}
            users={users}
            follows={follows}
            onClose={handleCloseFollowsModal}
            onFollow={handleFollow}
            onUnfollow={handleUnfollow}
            onViewProfile={(user) => {
              handleCloseFollowsModal();
              handleViewPublicProfile(user);
            }}
          />
      )}
    </div>
  );
};
