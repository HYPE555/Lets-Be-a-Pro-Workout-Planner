
import { GoogleGenAI, Type } from "@google/genai";
import { WorkoutPreferences, WorkoutPlan, UserProfile, Team } from '../types';
import { AppMode } from '../App';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const searchExercises = async (query: string): Promise<{ name: string; description: string; }[]> => {
    if (!query.trim()) {
        return [];
    }

    const prompt = `
      You are a fitness exercise database. Your task is to find exercises matching a search query.
      Search Query: "${query}"
      
      Return a list of up to 7 exercise names that closely match the query, along with a brief, clear description (15-20 words) for each.
      Focus on variety if the query is broad (e.g., "chest exercises").
      
      Return the result as a JSON object adhering to the schema.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    exercises: {
                        type: Type.ARRAY,
                        description: "A list of exercises matching the search query.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING, description: "The name of the exercise." },
                                description: { type: Type.STRING, description: "A brief description of the exercise." }
                            },
                            required: ["name", "description"]
                        }
                    }
                },
                required: ["exercises"]
            },
            thinkingConfig: { thinkingBudget: 0 }
        }
    });

    try {
        const jsonText = response.text.trim();
        const parsed = JSON.parse(jsonText);
        return parsed.exercises || [];
    } catch (error) {
        console.error("Failed to parse exercise search response:", error);
        return [];
    }
};


export const generateWorkoutPlan = async (preferences: WorkoutPreferences, appMode: AppMode, profile: UserProfile | null, teams: Team[]): Promise<WorkoutPlan> => {
  const customExercisesPrompt = preferences.customExercises && preferences.customExercises.length > 0
    ? `IMPORTANT: The user has specifically requested to include the following exercises in their plan: ${preferences.customExercises.map(ex => ex.name).join(', ')}. Please integrate these exercises into the weekly schedule on appropriate days.`
    : '';
    
  let systemPrompt = '';
  let teamPrompt = '';

  if (appMode === 'hockey') {
    if (profile?.teamId) {
        const teamName = teams.find(t => t.id === profile.teamId)?.name;
        if (teamName) {
            teamPrompt = `- Hockey Team: ${teamName}`;
        }
    }
    systemPrompt = `
    You are an elite strength and conditioning coach for professional ice hockey players. Your goal is to create a highly effective, safe, and personalized weekly workout plan that directly translates to improved on-ice performance.
    If the user provides their team name, subtly incorporate motivational language or context relevant to being part of a team (e.g., "for peak game-day performance with your team").
    
    Key considerations for hockey training:
    - Focus on exercises that improve explosive power (for skating, shooting, and checking), rotational strength (for shot power), single-leg strength and stability (for skating stride), and core stability.
    - Emphasize injury prevention for common hockey injuries, particularly in the hips, groin, and shoulders.
    - The plan must be periodized and balanced, ensuring adequate recovery to prevent overtraining.
    `;
  } else { // general mode
    systemPrompt = `
    You are an elite personal trainer and fitness expert. Your goal is to create a highly effective, safe, and personalized weekly workout plan based on the user's specific inputs.
    `;
  }

  const prompt = `
    ${systemPrompt}

    Create a detailed weekly workout plan for a user with the following profile:
    - Goals: ${preferences.goals.join(', ')}
    ${teamPrompt}
    - Fitness Level: ${preferences.fitnessLevel}
    - Available Days for Workout: ${preferences.availableDays.join(', ')}
    - Preferred Workout Duration: ${preferences.duration} minutes
    - Available Equipment: ${preferences.equipment.join(', ')}
    - Additional Notes: ${preferences.notes || 'None'}

    ${customExercisesPrompt}

    Structure the output as a JSON object that adheres to the provided schema. For each of the 7 days of the week (Monday to Sunday), create a workout plan.
    If a day is one of the user's available days, create a detailed workout session. If it is not an available day, the "focus" should be "Rest Day" or "Active Recovery".
    For each exercise, provide a brief, clear description (20-30 words) with essential form tips.
    
    Crucially, for each exercise, also provide 1-2 alternative variations. These variations should be suitable for the user's fitness level (e.g., an easier version for beginners, a harder one for advanced users) and consider their available equipment. Each variation must include a name and a brief description.

    The plan should be balanced and progressive. Include a suitable warm-up and cool-down for each session.
  `;
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          weeklyPlan: {
            type: Type.ARRAY,
            description: "An array of workout plans for each day of the week, from Monday to Sunday.",
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.STRING, description: "Day of the week (e.g., Monday)." },
                focus: { type: Type.STRING, description: "Main focus of the workout (e.g., Upper Body Strength, Explosive Power, Rest Day)." },
                warmup: { type: Type.STRING, description: "A brief description of the warm-up routine." },
                exercises: {
                  type: Type.ARRAY,
                  description: "A list of exercises for the workout session.",
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: "Name of the exercise." },
                      sets: { type: Type.INTEGER, description: "Number of sets." },
                      reps: { type: Type.STRING, description: "Number of repetitions (e.g., '8-12' or '30 seconds')." },
                      rest: { type: Type.STRING, description: "Rest period between sets (e.g., '60 seconds')." },
                      description: { type: Type.STRING, description: "Brief instructions or form tips for the exercise (20-30 words)." },
                      variations: {
                        type: Type.ARRAY,
                        description: "Alternative variations for the exercise, tailored to the user's fitness level and equipment.",
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            name: { type: Type.STRING, description: "Name of the variation exercise." },
                            description: { type: Type.STRING, description: "Brief instructions or form tips for the variation." }
                          },
                          required: ["name", "description"]
                        }
                      }
                    },
                    required: ["name", "sets", "reps", "rest", "description"],
                  }
                },
                cooldown: { type: Type.STRING, description: "A brief description of the cool-down routine." }
              },
              required: ["day", "focus", "warmup", "exercises", "cooldown"],
            }
          }
        },
        required: ["weeklyPlan"],
      },
    }
  });

  const jsonText = response.text.trim();
  try {
    const parsedPlan = JSON.parse(jsonText);
    return parsedPlan as WorkoutPlan;
  } catch (error) {
    console.error("Failed to parse JSON response:", jsonText);
    throw new Error("The AI returned an invalid response format.");
  }
};